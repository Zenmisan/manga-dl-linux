#include <QDirIterator>
#include <QFontDatabase>
#include <QGuiApplication>
#include <QIcon>
#include <QQmlApplicationEngine>
#include <QQuickStyle>
#include <QQuickWindow>
#include <QTimer>

#include "IconProvider.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QGuiApplication::setApplicationName(QStringLiteral("manga-dl"));
    QGuiApplication::setApplicationDisplayName(QStringLiteral("manga-dl"));
    QGuiApplication::setOrganizationDomain(QStringLiteral("zenmisan.github.io"));
    QGuiApplication::setDesktopFileName(QStringLiteral("io.github.zenmisan.MangaDl"));
    QGuiApplication::setWindowIcon(QIcon(QStringLiteral(":/qt/qml/MangaDl/assets/icons/manga-dl.png")));

    // Bundled fonts: Anton (display), Inter (UI), PT Serif (novel reader).
    QDirIterator fonts(QStringLiteral(":/qt/qml/MangaDl/assets/fonts"), {QStringLiteral("*.ttf")});
    while (fonts.hasNext())
        QFontDatabase::addApplicationFont(fonts.next());

    // Basic is the plainest Controls style; every control the app uses is restyled in QML.
    QQuickStyle::setStyle(QStringLiteral("Basic"));

    QQmlApplicationEngine engine;
    engine.addImageProvider(QStringLiteral("icon"), new IconProvider);
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &app,
                     [] { QCoreApplication::exit(1); }, Qt::QueuedConnection);
    // (QQmlApplicationEngine::loadFromModule needs Qt 6.5; a URL works on 6.4+.)
    engine.load(QUrl(QStringLiteral("qrc:/qt/qml/MangaDl/qml/Main.qml")));

    // Dev helper: MANGADL_SCREENSHOT=out.png saves the window after it settles, then quits.
    // Combine with `--page <Name>` to capture any screen (used to check against the designs).
    if (const QString shot = qEnvironmentVariable("MANGADL_SCREENSHOT"); !shot.isEmpty() && !engine.rootObjects().isEmpty()) {
        auto *window = qobject_cast<QQuickWindow *>(engine.rootObjects().constFirst());
        const int delay = qEnvironmentVariableIsSet("MANGADL_SCREENSHOT_DELAY") ? qEnvironmentVariableIntValue("MANGADL_SCREENSHOT_DELAY") : 1200;
        QTimer::singleShot(delay, window, [window, shot] {
            window->grabWindow().save(shot);
            QCoreApplication::quit();
        });
    }

    return app.exec();
}
