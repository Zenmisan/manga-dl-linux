#include "SampleData.h"

namespace {

// Manga: { id, title, cover (hex), unread, downloaded, inLibrary, source }
QVariantMap manga(const QString &id, const QString &title, const QString &cover, int unread = 0,
                  bool downloaded = false, bool inLibrary = false, const QString &source = QStringLiteral("MangaDex"))
{
    return {{"id", id}, {"title", title}, {"cover", cover}, {"unread", unread},
            {"downloaded", downloaded}, {"inLibrary", inLibrary}, {"source", source}};
}

const QVariantMap HollowCrown = manga("hollow-crown", "Hollow Crown", "#1A2433", 3, true, true);
const QVariantMap IronLantern = manga("iron-lantern", "Iron Lantern", "#3A1518", 2, false, true, "Asura Scans");
const QVariantMap AshenBlade = manga("ashen-blade", "Ashen Blade", "#2E2412", 12, true, true);
const QVariantMap NinthArchive = manga("ninth-archive", "The Ninth Archive", "#2D1716", 5, false, true, "MangaKatana");
const QVariantMap PaperMoon = manga("paper-moon", "Paper Moon Club", "#13282A", 1, false, true);
const QVariantMap RedThread = manga("red-thread", "Red Thread Pact", "#311A1F", 2, true, true, "Suwayomi");
const QVariantMap GlassGarden = manga("glass-garden", "Glass Garden", "#1D2A1A", 0, false, true);
const QVariantMap Tidebreaker = manga("tidebreaker", "Tidebreaker", "#1B2030", 0, true, true);
const QVariantMap NightMarket = manga("night-market", "Night Market Ghosts", "#2B1A2E", 0, false, true);
const QVariantMap SaltStatic = manga("salt-static", "Salt and Static", "#22222A", 0, false, true);

QVariantMap bar(const QString &name, double fraction) { return {{"name", name}, {"fraction", fraction}}; }

} // namespace

SampleData::SampleData(QObject *parent) : QObject(parent) {}

QVariantMap SampleData::featured() const { return HollowCrown; }

QVariantList SampleData::library() const
{
    return {HollowCrown, NightMarket, AshenBlade, PaperMoon, Tidebreaker, NinthArchive, GlassGarden,
            RedThread, SaltStatic, IronLantern,
            manga("seven-bells", "Seven Bells", "#1B2030"),
            manga("cold-forge", "Cold Forge", "#311A1F", 4),
            manga("second-sun", "Second Sun", "#13282A"),
            manga("ivory-wolves", "Ivory Wolves", "#2D1716")};
}

// { manga, where, progress 0–1 }
QVariantList SampleData::continueReading() const
{
    return {QVariantMap{{"manga", IronLantern}, {"where", "Ch. 112 · page 14 of 38"}, {"progress", 0.37}},
            QVariantMap{{"manga", HollowCrown}, {"where", "Ch. 48 · page 2 of 41"}, {"progress", 0.05}},
            QVariantMap{{"manga", RedThread}, {"where", "Ch. 9 · page 30 of 32"}, {"progress", 0.94}}};
}

QStringList SampleData::categories() const
{
    return {"All · 42", "Reading", "Plan to read", "Completed", "Local files"};
}

// { number, title, released, group, status, read }
QVariantList SampleData::chapters() const
{
    QVariantList list;
    const QList<std::pair<QString, QString>> rows = {
        {"51", "Download"}, {"50", "Downloaded"}, {"49", "Downloaded"}, {"48", "Page 14"},
        {"47", "Read"}, {"46", "Read"}, {"45", "Read"}, {"44", "Read"}};
    for (const auto &[number, status] : rows)
        list << QVariantMap{{"number", number}, {"title", "[Chapter title]"}, {"released", "[date]"},
                            {"group", "[scanlator]"}, {"status", status}, {"read", status == "Read"}};
    return list;
}

// [{ title, items: [{ manga, chapter, source }] }]
QVariantList SampleData::updates() const
{
    auto item = [](const QVariantMap &m, const QString &chapter, const QString &source) {
        return QVariantMap{{"manga", m}, {"chapter", chapter}, {"source", source}};
    };
    return {QVariantMap{{"title", "Today"},
                        {"items", QVariantList{item(HollowCrown, "Ch. 51 · [title]", "MangaDex"),
                                               item(AshenBlade, "Ch. 89 · [title]", "MangaDex"),
                                               item(AshenBlade, "Ch. 88 · [title]", "MangaDex"),
                                               item(IronLantern, "Ch. 113 · [title]", "Asura Scans")}}},
            QVariantMap{{"title", "Yesterday"},
                        {"items", QVariantList{item(NinthArchive, "Ch. 13 · [title]", "MangaKatana"),
                                               item(PaperMoon, "Ch. 4 · [title]", "MangaDex"),
                                               item(RedThread, "Ch. 10 · [title]", "Suwayomi")}}}};
}

// { manga, where, when }
QVariantList SampleData::history() const
{
    auto item = [](const QVariantMap &m, const QString &where, const QString &when) {
        return QVariantMap{{"manga", m}, {"where", where}, {"when", when}};
    };
    return {item(IronLantern, "Ch. 112 · page 14 of 38", "Today · [time]"),
            item(HollowCrown, "Ch. 48 · page 2 of 41", "Today · [time]"),
            item(RedThread, "Ch. 9 · page 30 of 32", "Yesterday"),
            item(GlassGarden, "Ch. 21 · finished", "[weekday]"),
            item(Tidebreaker, "Ch. 7 · page 11 of 26", "[weekday]"),
            item(SaltStatic, "Ch. 2 · finished", "[weekday]"),
            item(AshenBlade, "Ch. 87 · finished", "[weekday]"),
            item(NightMarket, "Ch. 30 · page 5 of 22", "[weekday]")};
}

// { title, body, when, unread, kind: info|error|success, icon, action }
QVariantList SampleData::notices() const
{
    auto n = [](const QString &title, const QString &body, const QString &when, bool unread, const QString &kind,
                const QString &icon, const QString &action = {}) {
        return QVariantMap{{"title", title}, {"body", body}, {"when", when}, {"unread", unread},
                           {"kind", kind}, {"icon", icon}, {"action", action}};
    };
    return {n("3 new chapters", "Hollow Crown Ch. 51, Ashen Blade Ch. 88–89", "[time]", true, "info", "Updates", "View"),
            n("Download failed", "Paper Moon Club Ch. 3 — source timed out", "[time]", true, "error", "Warning", "Retry"),
            n("Downloads finished", "4 chapters saved to ~/manga-library", "[time]", false, "success", "Download", "Open Folder"),
            n("Library synced", "Progress synced across your devices", "Yesterday", false, "info", "Refresh"),
            n("Update available", "manga-dl [version] is ready to install", "Yesterday", false, "info", "ArrowUp", "Install"),
            n("2 extensions updated", "Asura Scans and [Extension]", "[weekday]", false, "info", "Refresh")};
}

// { manga, chapter, status, progress, state: downloading|queued|paused|failed|done }
QVariantList SampleData::downloads() const
{
    auto d = [](const QVariantMap &m, const QString &chapter, const QString &status, double progress, const QString &state) {
        return QVariantMap{{"manga", m}, {"chapter", chapter}, {"status", status}, {"progress", progress}, {"state", state}};
    };
    return {d(AshenBlade, "Ch. 88", "Downloading · 24 / 41 pages", 0.58, "downloading"),
            d(AshenBlade, "Ch. 89", "Queued", 0, "queued"),
            d(NinthArchive, "Ch. 12", "Paused", 0.30, "paused"),
            d(PaperMoon, "Ch. 3", "Failed · source timed out", 0.12, "failed"),
            d(HollowCrown, "Ch. 51", "Done", 1, "done")};
}

// { name, meta, initial, color }
static QVariantMap source(const QString &name, const QString &meta, const QString &initial, const QString &color)
{
    return {{"name", name}, {"meta", meta}, {"initial", initial}, {"color", color}};
}

QVariantMap SampleData::lastUsedSource() const { return source("MangaDex", "English · Built-in", "M", "#2D1716"); }

QVariantList SampleData::sources() const
{
    return {source("MangaKatana", "English · Built-in", "K", "#1A2433"),
            source("Komga", "Self-hosted · Built-in", "K", "#13282A"),
            source("Suwayomi", "Self-hosted · Built-in", "S", "#2B1A2E"),
            source("Asura Scans", "English · Extension", "A", "#2E2412"),
            source("[Extension source]", "[Language] · Extension", "—", "#22222A")};
}

// { name, initial, color, language, version, state: update|installed|available|broken }
QVariantList SampleData::extensions() const
{
    auto e = [](const QString &name, const QString &initial, const QString &color, const QString &lang,
                const QString &version, const QString &state) {
        return QVariantMap{{"name", name}, {"initial", initial}, {"color", color}, {"language", lang},
                           {"version", version}, {"state", state}};
    };
    return {e("Asura Scans", "A", "#2E2412", "English", "v[x] → v[y]", "update"),
            e("[Extension]", "—", "#22222A", "English", "v[x] → v[y]", "update"),
            e("[Extension]", "—", "#2B1A2E", "English", "v[x]", "installed"),
            e("[Extension]", "—", "#13282A", "English", "v[x]", "available"),
            e("[Extension]", "—", "#1A2433", "Multi", "v[x]", "available"),
            e("[Extension]", "—", "#311A1F", "English", "v[x]", "available"),
            e("[Extension]", "—", "#1D2A1A", "English", "v[x]", "broken")};
}

// { name, short, color, description, connected }
QVariantList SampleData::trackers() const
{
    auto t = [](const QString &name, const QString &shortName, const QString &color, const QString &desc, bool connected = false) {
        return QVariantMap{{"name", name}, {"short", shortName}, {"color", color}, {"description", desc}, {"connected", connected}};
    };
    return {t("AniList", "AL", "#1E3A5F", "Sync status, score, chapters read and dates.", true),
            t("MyAnimeList", "MAL", "#1F2C4F", "Sync manga status with MyAnimeList.", true),
            t("Kitsu", "K", "#3B1F2E", "Sync manga progress with Kitsu."),
            t("MangaUpdates", "MU", "#2E2412", "Keep your MangaUpdates lists current."),
            t("Shikimori", "S", "#22222A", "Sync progress with Shikimori."),
            t("Bangumi", "B", "#311A1F", "Sync progress with Bangumi.")};
}

// [{ source, meta, results: [manga] }]
QVariantList SampleData::searchResults() const
{
    return {QVariantMap{{"source", "MangaDex"}, {"meta", "12 results"},
                        {"results", QVariantList{HollowCrown, manga("crown-of-ash", "Crown of Ash", "#2E2412"),
                                                 manga("paper-crown", "The Paper Crown", "#2B1A2E"),
                                                 manga("crownless", "Crownless", "#13282A"),
                                                 manga("crown-tide", "Crown & Tide", "#1B2030"),
                                                 manga("ember-crown", "Ember Crown", "#311A1F"),
                                                 manga("glass-crown", "Glass Crown", "#1D2A1A")}}},
            QVariantMap{{"source", "MangaKatana"}, {"meta", "4 results"},
                        {"results", QVariantList{HollowCrown, manga("iron-crown", "Iron Crown Saga", "#311A1F"),
                                                 manga("crown-tide-2", "Crown & Tide", "#1B2030"),
                                                 manga("thorn-crown", "Thorn Crown", "#22222A")}}}};
}

QVariantList SampleData::browseCatalog() const
{
    return {AshenBlade, manga("lantern-street", "Lantern Street", "#1A2433"), manga("ghost-ferry", "Ghost Ferry", "#2B1A2E"),
            manga("second-sun-2", "Second Sun", "#13282A"), HollowCrown, manga("ivory-wolves-2", "Ivory Wolves", "#2D1716"),
            manga("low-tide", "Low Tide Saints", "#1D2A1A"), PaperMoon, manga("neon-shrine", "Neon Shrine", "#22222A"),
            manga("cold-forge-2", "Cold Forge", "#311A1F"), manga("seven-bells-2", "Seven Bells", "#1B2030"),
            manga("rust-garden", "Rust Garden", "#2E2412"), manga("moth-kingdom", "Moth Kingdom", "#2B1A2E"),
            manga("quiet-engine", "Quiet Engine", "#22222A"), manga("blue-hour", "Blue Hour", "#1B2030"),
            manga("saltwind", "Saltwind", "#13282A")};
}

// { name, ext, status, progress, kind: done|busy|queued|error }
QVariantList SampleData::importQueue() const
{
    auto f = [](const QString &name, const QString &ext, const QString &status, double progress, const QString &kind) {
        return QVariantMap{{"name", name}, {"ext", ext}, {"status", status}, {"progress", progress}, {"kind", kind}};
    };
    return {f("[Series] Vol. 01.cbz", "CBZ", "Imported", 1, "done"),
            f("[Series] Vol. 02.cbz", "CBZ", "Importing…", 0.46, "busy"),
            f("[Series] extras/", "DIR", "Waiting", 0, "queued"),
            f("notes.pdf", "PDF", "Unsupported format", 1, "error")};
}

QVariantList SampleData::byCategory() const
{
    return {bar("Reading", 0.70), bar("Completed", 0.45), bar("Plan to read", 0.20), bar("Local files", 0.12)};
}

QVariantList SampleData::bySource() const
{
    return {bar("MangaDex", 0.64), bar("MangaKatana", 0.24), bar("Asura Scans", 0.18), bar("Local files", 0.12)};
}

// Deterministic 0–3 intensity per day for the 52-week heatmap (column-major: 7 days per week).
QVariantList SampleData::activity() const
{
    QVariantList list;
    for (int i = 0; i < 364; ++i) {
        const int v = (i * 37 + i / 7 * 11) % 13;
        list << (v < 5 ? 0 : v < 9 ? 1 : v < 12 ? 2 : 3);
    }
    return list;
}
