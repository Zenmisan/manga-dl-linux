#pragma once

#include <QObject>
#include <QVariantList>
#include <QVariantMap>
#include <QtQml/qqmlregistration.h>

/// Placeholder data so every screen renders like the designs.
/// Exposed to QML as the `Sample` singleton. Replace each property with a real
/// model (QAbstractListModel or a QObject with NOTIFY signals) when wiring the backend;
/// the QML only reads the role/key names used here.
/// Values in [brackets] are the same placeholders used in the mockups.
class SampleData : public QObject
{
    Q_OBJECT
    QML_NAMED_ELEMENT(Sample)
    QML_SINGLETON

    Q_PROPERTY(QVariantList library READ library CONSTANT)
    Q_PROPERTY(QVariantList continueReading READ continueReading CONSTANT)
    Q_PROPERTY(QStringList categories READ categories CONSTANT)
    Q_PROPERTY(QVariantList chapters READ chapters CONSTANT)
    Q_PROPERTY(QVariantList updates READ updates CONSTANT)
    Q_PROPERTY(QVariantList history READ history CONSTANT)
    Q_PROPERTY(QVariantList notices READ notices CONSTANT)
    Q_PROPERTY(QVariantList downloads READ downloads CONSTANT)
    Q_PROPERTY(QVariantMap lastUsedSource READ lastUsedSource CONSTANT)
    Q_PROPERTY(QVariantList sources READ sources CONSTANT)
    Q_PROPERTY(QVariantList extensions READ extensions CONSTANT)
    Q_PROPERTY(QVariantList trackers READ trackers CONSTANT)
    Q_PROPERTY(QVariantList searchResults READ searchResults CONSTANT)
    Q_PROPERTY(QVariantList browseCatalog READ browseCatalog CONSTANT)
    Q_PROPERTY(QVariantList importQueue READ importQueue CONSTANT)
    Q_PROPERTY(QVariantList byCategory READ byCategory CONSTANT)
    Q_PROPERTY(QVariantList bySource READ bySource CONSTANT)
    Q_PROPERTY(QVariantList activity READ activity CONSTANT)
    Q_PROPERTY(QVariantMap featured READ featured CONSTANT)

public:
    explicit SampleData(QObject *parent = nullptr);

    QVariantList library() const;
    QVariantList continueReading() const;
    QStringList categories() const;
    QVariantList chapters() const;
    QVariantList updates() const;
    QVariantList history() const;
    QVariantList notices() const;
    QVariantList downloads() const;
    QVariantMap lastUsedSource() const;
    QVariantList sources() const;
    QVariantList extensions() const;
    QVariantList trackers() const;
    QVariantList searchResults() const;
    QVariantList browseCatalog() const;
    QVariantList importQueue() const;
    QVariantList byCategory() const;
    QVariantList bySource() const;
    QVariantList activity() const;
    /// The manga shown when Detail/Reader are opened without a parameter.
    QVariantMap featured() const;
};
