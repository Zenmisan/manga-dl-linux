# manga-dl for Linux (Qt 6 · QML + C++)

A native Linux UI for manga-dl, built from the design canvas. It contains **the screens
only**: every list is filled from `src/SampleData.cpp`, and every action that would talk to a
backend is marked `TODO(backend)`.

All 28 screens were compiled and rendered with Qt 6.4. You can see them in
`docs/screenshots/`. Navigation, the reader keys and the live accent switch were also tested
by clicking through the running app.

## Requirements

- Qt **6.4 or newer** with these modules: Qt Quick, Quick Controls 2, Quick Layouts, Svg.
- CMake 3.21+ and a C++20 compiler (GCC 11+ or Clang 14+).

Install the dependencies for your distro:

| Distro | Command |
|---|---|
| Ubuntu / Debian | `sudo apt install build-essential cmake qt6-base-dev qt6-declarative-dev qt6-svg-dev qml6-module-qtquick qml6-module-qtquick-controls qml6-module-qtquick-layouts qml6-module-qtquick-window qml6-module-qtquick-templates qml6-module-qtqml-workerscript` |
| Fedora | `sudo dnf install cmake gcc-c++ qt6-qtbase-devel qt6-qtdeclarative-devel qt6-qtsvg-devel` |
| Arch | `sudo pacman -S cmake qt6-base qt6-declarative qt6-svg` |

## Build and run

```sh
cmake -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j
./build/manga-dl                    # opens on Onboarding
./build/manga-dl --page Library     # or start on any screen
```

Debug builds add **All pages (debug)** to the sidebar. It jumps straight to any screen,
settings section, the update dialog or the toast. Release builds hide it.

To install (binary, `.desktop` file and icon):

```sh
cmake -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr
cmake --build build -j && sudo cmake --install build
```

Qt Creator can also open `CMakeLists.txt` directly.

## Layout

```
CMakeLists.txt
src/
  main.cpp            app setup: fonts, Basic style, icon provider, loads qml/Main.qml
  SampleData.h/.cpp   `Sample` QML singleton: every list the screens show (replace with real models)
  IconProvider.*      line icons as image://icon/<Name>?color=…  (same paths as Android/Windows)
  AppInfo.h           `AppInfo` singleton: version, debug flag
qml/
  Main.qml            window: sidebar + page stack (fade transitions), update dialog, toast
  theme/Theme.qml     design tokens: colours, fonts, accent switching
  theme/Nav.qml       navigation: Nav.go / Nav.open / Nav.back / Nav.toast / Nav.showUpdateDialog
  components/         Btn, Chip, MdSwitch, Segmented, Tabs, Field, SearchField, Card, SettingRow,
                      CoverTile, AutoGrid, Icon, Sidebar, Toast, UpdateDialog, …
  pages/              one file per screen (<Name>Page.qml)
  pages/settings/     settings host and its six sections
assets/fonts          Anton, Inter, PT Serif (all SIL Open Font License)
assets/icons          app icon (placeholder art; replace at the same size)
packaging/            .desktop file
docs/screenshots/     every screen at 1440×900
```

## Wiring the backend

- **Data.** `SampleData` is the only data source. Replace its properties with your own C++
  types: a `QAbstractListModel` for lists, or a `QObject` with `NOTIFY` signals. Register
  them with `QML_ELEMENT` or `QML_SINGLETON`. The QML reads the same key names as the sample
  maps, such as `manga.title`, `manga.cover`, `progress` and `state`, and the comments in
  `SampleData.cpp` list them.
- **Actions.** Run `grep -rn "TODO(backend)" qml src` to find every stub.
- **Navigation.** Page names match the file names in `qml/pages`:
  - `Nav.go("Library")` switches section and resets history.
  - `Nav.open("MangaDetail", { manga: m })` pushes a page on top.
  - Pages that take parameters:
    - `MangaDetail` and `Reader` take `manga`. `Reader` also takes `layout: "single"`.
    - `Extensions` takes `tab: "sources" | "migrate"`.
    - `BrowseSource` takes `source`.
    - `Settings` takes `section: "Account" | "General" | "Reader" | "Library" | "Trackers" | "System"`.
- **Accent colour.** `Theme.setAccent(name)` recolours the whole app live. Save the choice
  (for example with `QSettings`) and call it at startup.
- **Covers and pages.** `CoverArt` and `PagePlaceholder` are colour blocks for now. Swap in an
  `Image` bound to your cover or page URL.
- **File pickers.** The Import screen shows where to add `QtQuick.Dialogs` `FileDialog` and
  `FolderDialog`.

## Title bar

The window keeps the desktop's own title bar (GNOME, KDE and others draw it), as agreed. To
use a custom one, set `flags: Qt.Window | Qt.FramelessWindowHint` on the window in
`Main.qml`. Then add a 40px bar that calls `startSystemMove()` from a `DragHandler`.

## Screenshot helper (development)

```sh
QT_QPA_PLATFORM=offscreen MANGADL_SCREENSHOT=out.png ./build/manga-dl --page Settings --param section=Reader
```

This saves the window after about a second, then quits. `--param key=value` can be repeated.
It is how `docs/screenshots` was made.

Not included, as agreed: DownloadHub, Landing and Terms.
