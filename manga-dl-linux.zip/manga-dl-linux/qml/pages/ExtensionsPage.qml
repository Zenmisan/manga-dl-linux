import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

// Browse: Sources / Extensions / Migrate tabs. Open with { tab: "sources" | "migrate" }.
Item {
    id: page
    property string tab: "extensions"
    readonly property int tabIndex: tab === "sources" ? 0 : tab === "migrate" ? 2 : 1

    function extStatus(s) { return s === "update" ? "Update available" : s === "installed" ? "Installed" : s === "broken" ? "Failed to load" : "Not installed" }
    function extStatusColor(s) { return s === "update" ? Theme.accentSoft : s === "installed" ? Theme.successText : s === "broken" ? Theme.errorText : Theme.fgSubtle }
    function extAction(s) { return s === "update" ? "Update" : s === "installed" ? "Uninstall" : s === "broken" ? "Reinstall" : "Install" }

    component SourceRow: Item {
        property var source
        Layout.fillWidth: true
        width: parent ? parent.width : 0
        height: 62
        HairLine { width: parent.width }
        RowLayout {
            anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
            spacing: 14
            Initial { size: 40; text: source.initial; color: source.color; radius: 10 }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 0
                Txt { Layout.fillWidth: true; text: source.name; font.pixelSize: 15; font.weight: Font.Bold }
                Caption { Layout.fillWidth: true; text: source.meta }
            }
            Btn { kind: "ghost"; size: "pill"; text: "Popular"; onClicked: Nav.open("BrowseSource", { source: source.name }) }
            Btn { kind: "ghost"; size: "pill"; text: "Latest"; onClicked: Nav.open("BrowseSource", { source: source.name }) }
            Btn { kind: "icon"; iconName: "Pin"; iconSize: 18; textColor: Theme.fgSubtle; Accessible.name: "Pin source" }
        }
    }

    PageScroll {
        anchors.fill: parent
        spacing: 18

        RowLayout {
            width: parent.width
            spacing: 12
            PageTitle { text: "Browse"; Layout.fillWidth: true }
            // Looks like a search field; opens global search.
            Clickable {
                implicitWidth: 340; implicitHeight: 42
                radius: 12
                fill: Theme.surfaceRaised
                Accessible.name: "Search all sources"
                onClicked: Nav.open("Search")
                Rectangle { anchors.fill: parent; radius: 12; color: "transparent"; border.color: Theme.track }
                Row {
                    x: 14; anchors.verticalCenter: parent.verticalCenter
                    spacing: 10
                    Icon { name: "Search"; size: 18; color: Theme.fgSubtle }
                    Txt { text: "Search all sources"; color: Theme.fgSubtle; anchors.verticalCenter: parent.verticalCenter }
                }
            }
        }

        Tabs {
            width: parent.width
            model: ["Sources · 6", "Extensions", "Migrate"]
            currentIndex: page.tabIndex
            onActivated: index => page.tab = ["sources", "extensions", "migrate"][index]
        }

        // ===== Sources =====
        Column {
            visible: page.tab === "sources"
            width: parent.width
            Eyebrow { text: "Last used"; topPadding: 4; bottomPadding: 4 }
            SourceRow { source: Sample.lastUsedSource }
            Eyebrow { text: "All sources"; muted: true; topPadding: 18; bottomPadding: 4 }
            Repeater { model: Sample.sources; SourceRow { required property var modelData; source: modelData } }
        }

        // ===== Extensions =====
        Column {
            visible: page.tab === "extensions"
            width: parent.width
            spacing: 18
            RowLayout {
                width: parent.width
                spacing: 8
                ButtonGroup { id: lang }
                Chip { small: true; text: "English"; checked: true; ButtonGroup.group: lang }
                Chip { small: true; text: "All languages"; ButtonGroup.group: lang }
                Chip { small: true; text: "Show 18+" }
                Item { Layout.fillWidth: true }
                Txt { text: "Index: Keiyoushi · refreshed [time]"; font.pixelSize: 13; color: Theme.fgSubtle; Layout.rightMargin: 8 }
                Btn { text: "Update All · 2"; implicitHeight: 38; radius: 10 }
            }
            Column {
                width: parent.width
                RowLayout {
                    width: parent.width
                    height: 36
                    spacing: 16
                    TableHeader { text: "Extension"; Layout.fillWidth: true; Layout.leftMargin: 12 }
                    TableHeader { text: "Language"; Layout.preferredWidth: 120 }
                    TableHeader { text: "Version"; Layout.preferredWidth: 140 }
                    TableHeader { text: "Status"; Layout.preferredWidth: 160 }
                    TableHeader { text: "Action"; Layout.preferredWidth: 140; horizontalAlignment: Text.AlignRight; Layout.rightMargin: 12 }
                }
                Repeater {
                    model: Sample.extensions
                    delegate: Item {
                        required property var modelData
                        width: parent.width
                        height: 56
                        HairLine { width: parent.width }
                        RowLayout {
                            anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                            spacing: 16
                            Row {
                                Layout.fillWidth: true
                                spacing: 12
                                Rectangle {
                                    width: 36; height: 36; radius: 9; color: modelData.color
                                    DisplayText { anchors.centerIn: parent; text: modelData.initial; font.pixelSize: 15 }
                                }
                                Txt { text: modelData.name; font.weight: Font.Bold; anchors.verticalCenter: parent.verticalCenter }
                            }
                            Txt { text: modelData.language; font.pixelSize: 13; color: Theme.fgSoft; Layout.preferredWidth: 120 }
                            Txt { text: modelData.version; font.pixelSize: 13; color: Theme.fgSoft; Layout.preferredWidth: 140 }
                            Txt { text: page.extStatus(modelData.state); font.pixelSize: 12; font.weight: Font.Bold; color: page.extStatusColor(modelData.state); Layout.preferredWidth: 160 }
                            Item {
                                Layout.preferredWidth: 140
                                implicitHeight: 36
                                Btn {
                                    anchors.right: parent.right
                                    size: "small"
                                    kind: modelData.state === "update" ? "primary" : modelData.state === "broken" ? "danger" : "ghost"
                                    text: page.extAction(modelData.state)
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== Migrate =====
        Column {
            visible: page.tab === "migrate"
            width: parent.width
            spacing: 8
            BodyMuted { width: parent.width; text: "Move a manga to another source and keep its read chapters, categories and tracking."; bottomPadding: 8 }
            Column {
                width: parent.width
                Repeater {
                    model: Sample.library
                    delegate: Item {
                        required property var modelData
                        width: parent.width
                        height: 70
                        HairLine { width: parent.width }
                        RowLayout {
                            anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                            spacing: 16
                            CoverArt { width: 36; height: 54; radius: 6; cover: modelData.cover }
                            Txt { text: modelData.title; font.weight: Font.Bold; Layout.fillWidth: true }
                            Txt { text: modelData.source; font.pixelSize: 13; color: Theme.fgSubtle; Layout.preferredWidth: 200 }
                            // TODO(backend): open the migration flow.
                            Btn { kind: "ghost"; size: "small"; text: "Migrate"; onClicked: Nav.toast("Pick a target source to migrate to") }
                        }
                    }
                }
            }
        }
    }
}
