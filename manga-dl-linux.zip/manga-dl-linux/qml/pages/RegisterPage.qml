import QtQuick
import QtQuick.Layouts
import MangaDl

// Create account, with live password strength and match checks.
AuthLayout {
    id: page
    eyebrow: "Step 3 of 3"
    title: "Create account"
    subtitle: "Free. Keeps your library, history and backups in sync across devices."
    formSpacing: 14

    readonly property string pw: password.text
    readonly property bool matches: pw === confirm.text
    readonly property int score: (pw.length >= 8) + /[A-Za-z]/.test(pw) + /[0-9]/.test(pw) + (/[^A-Za-z0-9]/.test(pw) || pw.length >= 12)
    readonly property int bars: Math.min(4, score)

    LabeledField { label: "Username"; text: "[username]" }
    LabeledField { label: "Email"; placeholderText: "you@example.com" }
    RowLayout {
        Layout.fillWidth: true
        spacing: 12
        LabeledField { id: password; label: "Password"; text: "password1"; password: true; Layout.preferredWidth: 1 }
        LabeledField { id: confirm; label: "Confirm"; text: "password1"; password: true; error: !page.matches; Layout.preferredWidth: 1 }
    }
    ColumnLayout {
        Layout.fillWidth: true
        spacing: 6
        RowLayout {
            Layout.fillWidth: true
            spacing: 4
            Repeater {
                model: 4
                Rectangle {
                    required property int index
                    Layout.fillWidth: true
                    height: 4; radius: 2
                    color: index < page.bars ? (page.bars >= 3 ? Theme.success : Theme.accent) : Theme.line
                }
            }
        }
        Txt {
            text: !page.matches ? "Passwords don't match." : page.bars >= 3 ? "Strong password · passwords match" : "Weak password · passwords match"
            font.pixelSize: 12; font.weight: Font.DemiBold
            color: page.matches && page.bars >= 3 ? Theme.successText : Theme.errorText
        }
    }
    Row {
        CheckRow { id: terms; text: "I agree to the"; checked: true; font.pixelSize: 13 }
        Btn { kind: "link"; text: "Terms"; fontSize: 13; anchors.verticalCenter: parent.verticalCenter }
    }
    // TODO(backend): create the account.
    Btn {
        Layout.fillWidth: true; size: "large"; text: "Create Account"
        enabled: terms.checked && page.matches && page.pw.length > 0
        onClicked: Nav.home()
    }
    Row {
        Layout.topMargin: 6
        BodyMuted { text: "Have an account?"; anchors.verticalCenter: parent.verticalCenter }
        Btn { kind: "link"; text: "Sign in"; onClicked: Nav.go("Login") }
    }
}
