import QtQuick
import QtQuick.Layouts
import MangaDl

// Public reader profile.
Item {
    PageScroll {
        anchors.fill: parent
        padding: 0
        topPadding: 0
        spacing: 0

        // Banner + avatar
        Rectangle { width: parent.width; height: 180; color: "#2D1716" }
        RowLayout {
            x: 40
            width: parent.width - 80
            spacing: 16
            Rectangle {
                Layout.alignment: Qt.AlignTop
                Layout.topMargin: -64
                width: 140; height: 140; radius: 70
                color: Theme.bg
                Initial { anchors.centerIn: parent; size: 128; round: true; color: "#3A1518"; text: "U"; fontSize: 44 }
            }
            ColumnLayout {
                Layout.fillWidth: true
                Layout.alignment: Qt.AlignTop
                Layout.topMargin: 16
                Layout.leftMargin: 8
                spacing: 2
                Txt { Layout.fillWidth: true; text: "[Display name]"; font.pixelSize: 30; font.weight: Font.Black }
                Caption { Layout.fillWidth: true; text: "@[username] · reading since [date]"; font.pixelSize: 14 }
            }
            Btn { Layout.alignment: Qt.AlignTop; Layout.topMargin: 16; kind: "ghost"; text: "Share"; iconName: "Share" }
            Btn { Layout.alignment: Qt.AlignTop; Layout.topMargin: 16; text: "Edit Profile"; iconName: "Edit"; onClicked: Nav.go("Settings", { section: "Account" }) }
        }

        RowLayout {
            x: 40
            width: parent.width - 80
            spacing: 32
            // Space below the header row
            Layout.topMargin: 28
            y: 0

            ColumnLayout {
                Layout.fillWidth: true
                Layout.preferredWidth: 2
                Layout.alignment: Qt.AlignTop
                Layout.topMargin: 28
                spacing: 24
                Txt { Layout.fillWidth: true; text: "[Bio — a short line about what this reader likes.]"; font.pixelSize: 15; color: Theme.fgStrong; wrapMode: Text.Wrap }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    Eyebrow { text: "Pinned" }
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 16
                        Repeater {
                            model: ["#3A1518", "#1A2433", "#2E2412", "#13282A"]
                            Rectangle { required property string modelData; Layout.fillWidth: true; Layout.preferredWidth: 1; height: 250; radius: 12; color: modelData }
                        }
                    }
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                Layout.preferredWidth: 1
                Layout.alignment: Qt.AlignTop
                Layout.topMargin: 28
                spacing: 20
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10
                    Repeater {
                        model: [["[n]", "Chapters"], ["[n]", "Library"], ["[n]", "Day streak"]]
                        Rectangle {
                            required property var modelData
                            Layout.fillWidth: true; Layout.preferredWidth: 1
                            height: 86; radius: 14; color: Theme.surface
                            Column {
                                anchors.centerIn: parent
                                DisplayText { text: modelData[0]; font.pixelSize: 28; upper: false; anchors.horizontalCenter: parent.horizontalCenter }
                                Caption { text: modelData[1]; anchors.horizontalCenter: parent.horizontalCenter }
                            }
                        }
                    }
                }
                ColumnLayout {
                    spacing: 10
                    Eyebrow { text: "Milestones"; muted: true }
                    Flow {
                        Layout.fillWidth: true
                        spacing: 8
                        Repeater {
                            model: ["[Milestone]", "[Milestone]", "[Milestone]", "[Locked]"]
                            Rectangle {
                                required property string modelData
                                readonly property bool locked: modelData === "[Locked]"
                                width: label.implicitWidth + 24; height: 32; radius: 16
                                color: locked ? "transparent" : Theme.accentMuted
                                border.width: locked ? 1 : 0
                                border.color: Theme.switchOff
                                Txt { id: label; anchors.centerIn: parent; text: modelData; font.pixelSize: 12; font.weight: parent.locked ? Font.DemiBold : Font.Bold; color: parent.locked ? Theme.fgSubtle : Theme.accentSoft }
                            }
                        }
                    }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 0
                    Eyebrow { text: "Recent activity"; muted: true; Layout.bottomMargin: 6 }
                    Repeater {
                        model: ["Read Iron Lantern Ch. 112", "Finished Glass Garden", "Added Ashen Blade to library"]
                        Item {
                            required property string modelData
                            required property int index
                            Layout.fillWidth: true
                            height: 36
                            Txt { text: modelData; font.pixelSize: 13; color: Theme.fgStrong; anchors.verticalCenter: parent.verticalCenter }
                            HairLine { visible: index < 2; anchors.bottom: parent.bottom; width: parent.width }
                        }
                    }
                }
            }
        }
        Item { width: 1; height: 40 }
    }
}
