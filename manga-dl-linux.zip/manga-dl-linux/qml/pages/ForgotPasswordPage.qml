import QtQuick
import QtQuick.Layouts
import MangaDl

// Forgot password: email form, then a "link sent" state with a resend countdown.
AuthLayout {
    id: page
    title: "Reset password"
    subtitle: "Enter your account email. We'll send a link to set a new password."
    property bool sent: false
    property int countdown: 45

    Timer { running: page.sent && page.countdown > 0; interval: 1000; repeat: true; onTriggered: page.countdown-- }

    Btn { kind: "link"; text: "Back to Sign In"; fontSize: 13; iconName: "Back"; iconSize: 14; onClicked: Nav.back() }
    LabeledField { label: "Email"; text: "you@example.com" }
    // TODO(backend): send the reset email.
    Btn { visible: !page.sent; Layout.fillWidth: true; size: "large"; text: "Send Reset Link"; onClicked: page.sent = true }

    Btn { visible: page.sent; Layout.fillWidth: true; kind: "success"; size: "large"; text: "Link Sent"; iconName: "Check"; iconSize: 18; enabled: false; opacity: 1 }
    Card {
        visible: page.sent
        Layout.fillWidth: true
        kind: "list"; padding: 16
        Txt {
            Layout.fillWidth: true
            text: "If an account exists for that email, a reset link is on its way. Check your spam folder too."
            color: Theme.fgStrong; wrapMode: Text.Wrap; lineHeightMode: Text.FixedHeight; lineHeight: 21
        }
    }
    Btn {
        visible: page.sent
        kind: "link"; fontSize: 13
        enabled: page.countdown === 0
        textColor: enabled ? Theme.accentLight : Theme.fgMuted
        text: page.countdown > 0 ? "Resend in 0:" + ("0" + page.countdown).slice(-2) : "Resend link"
        onClicked: page.countdown = 45
    }
}
