import QtQuick
import QtQuick.Layouts
import MangaDl

SettingsSection {
    id: section
    title: "Library"
    caption: "Categories, how the grid looks and when to check for new chapters."

    // TODO(backend): load categories from the library.
    property var categories: ["Default", "Reading", "Plan to read", "Completed", "Local files"]
    property int editing: -2          // -2 closed, -1 adding, >= 0 renaming that row

    function openEditor(index) { editing = index; nameField.text = index >= 0 ? categories[index] : ""; nameField.forceActiveFocus() }
    function save() {
        const name = nameField.text.trim()
        if (!name) return
        const list = categories.slice()
        if (editing >= 0) list[editing] = name; else list.push(name)
        categories = list
        editing = -2
    }
    function remove(index) {
        const name = categories[index]
        const list = categories.slice(); list.splice(index, 1); categories = list
        Nav.toast("Deleted \"" + name + "\"")
    }

    TwoColumns {
        leftCards: [
            SettingsCard {
                spacing: 12
                RowLayout {
                    Layout.fillWidth: true
                    Eyebrow { text: "Categories"; Layout.fillWidth: true }
                    Btn { size: "small"; text: "Add"; iconName: "Plus"; iconSize: 14; onClicked: section.openEditor(-1) }
                }
                RowLayout {
                    visible: section.editing > -2
                    Layout.fillWidth: true
                    spacing: 8
                    Field {
                        id: nameField
                        Layout.fillWidth: true
                        placeholderText: "Category name"
                        onAccepted: section.save()
                        Keys.onEscapePressed: section.editing = -2
                    }
                    Btn { text: "Save"; onClicked: section.save() }
                    Btn { kind: "ghost"; text: "Cancel"; onClicked: section.editing = -2 }
                }
                Repeater {
                    model: section.categories
                    Rectangle {
                        required property string modelData
                        required property int index
                        Layout.fillWidth: true
                        height: 52
                        radius: 12
                        color: Theme.surface
                        RowLayout {
                            anchors { fill: parent; leftMargin: 12; rightMargin: 6 }
                            spacing: 10
                            Icon { name: "Grip"; size: 16; color: Theme.fgFaint }
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 0
                                Txt { Layout.fillWidth: true; text: modelData; font.weight: Font.DemiBold }
                                Caption { Layout.fillWidth: true; text: "[n] manga" }
                            }
                            Btn { kind: "icon"; iconName: "Edit"; iconSize: 16; implicitHeight: 36; Accessible.name: "Rename"; onClicked: section.openEditor(index) }
                            Btn { kind: "icon"; iconName: "Trash"; iconSize: 16; implicitHeight: 36; Accessible.name: "Delete"; onClicked: section.remove(index) }
                        }
                    }
                }
                Caption { Layout.fillWidth: true; wrapMode: Text.Wrap; text: "Drag to reorder. Deleting a category moves its manga to Default." }
            }
        ]
        rightCards: [
            SettingsCard {
                heading: "Display"
                SettingRow { label: "Grid columns"; description: "Auto fits as many covers as the window allows."; below: [ Segmented { model: ["Auto", "5", "6", "7", "8"] } ] }
                SettingRow { label: "Unread badges"; MdSwitch { checked: true } }
                SettingRow { label: "Downloaded badges"; MdSwitch { checked: true } }
                SettingRow { label: "Continue reading row"; showDivider: false; MdSwitch { checked: true } }
            },
            SettingsCard {
                heading: "Updates"
                SettingRow { label: "Check for new chapters"; MdCombo { model: ["Manually", "Every 6 hours", "Every 12 hours", "Daily", "Weekly"]; currentIndex: 2; Accessible.name: "Check for new chapters" } }
                SettingRow { label: "Only on unmetered networks"; MdSwitch { checked: true } }
                SettingRow { label: "Skip completed series"; showDivider: false; MdSwitch { checked: true } }
            },
            SettingsCard {
                heading: "Migration"
                SettingRow {
                    label: "Migrate between sources"; description: "Move manga to another source and keep your progress."; showDivider: false
                    Btn { kind: "ghost"; size: "small"; text: "Open"; onClicked: Nav.open("Extensions", { tab: "migrate" }) }
                }
            }
        ]
    }
}
