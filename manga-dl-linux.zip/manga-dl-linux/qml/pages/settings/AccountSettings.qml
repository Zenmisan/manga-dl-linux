import QtQuick
import QtQuick.Layouts
import MangaDl

SettingsSection {
    id: section
    title: "Account"
    caption: "Your profile, sync and sign-in."
    property bool confirmSignOut: false

    // Profile summary
    Card {
        width: parent.width
        RowLayout {
            Layout.fillWidth: true
            spacing: 16
            Initial { size: 64; round: true; color: "#3A1518"; text: "U"; fontSize: 24 }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Txt { Layout.fillWidth: true; text: "[Display name]"; font.pixelSize: 18; font.weight: Font.ExtraBold }
                Caption { Layout.fillWidth: true; text: "@[username] · [email]"; font.pixelSize: 13 }
            }
            Btn { kind: "ghost"; text: "View profile"; onClicked: Nav.go("Profile") }
        }
    }

    TwoColumns {
        leftCards: [
            SettingsCard {
                heading: "Public profile"
                spacing: 14
                LabeledField { label: "Display name"; placeholderText: "[Display name]" }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    FieldLabel { text: "Bio" }
                    MdTextArea { Layout.fillWidth: true; Layout.preferredHeight: 96; placeholderText: "A short line about what you like to read" }
                }
                SettingRow {
                    label: "Show reading activity"; description: "Let others see what you're reading and your stats."; showDivider: false
                    MdSwitch { checked: true }
                }
                // TODO(backend): save profile fields.
                Btn { text: "Save changes"; onClicked: Nav.toast("Profile saved") }
            }
        ]
        rightCards: [
            Card {
                width: parent.width
                color: Theme.successWash
                border.color: Theme.successLine
                spacing: 10
                RowLayout {
                    spacing: 10
                    Rectangle {
                        width: 36; height: 36; radius: 10; color: Theme.successSoft
                        Icon { anchors.centerIn: parent; name: "CloudCheck"; size: 18; color: Theme.successText }
                    }
                    ColumnLayout {
                        spacing: 0
                        Txt { Layout.fillWidth: true; text: "Cloud sync is on"; font.pixelSize: 15; font.weight: Font.ExtraBold }
                        Caption { Layout.fillWidth: true; text: "Last synced [time] · [n] devices"; color: Theme.successText }
                    }
                }
                BodyMuted { Layout.fillWidth: true; text: "Library, progress, categories and settings follow you across Android, Windows and Linux." }
                Row {
                    spacing: 8
                    // TODO(backend): trigger a sync.
                    Btn { kind: "success"; text: "Sync now"; onClicked: Nav.toast("Synced") }
                    Btn { kind: "ghost"; text: "Manage devices" }
                }
            },
            SettingsCard {
                heading: "Sign-in"
                SettingRow { label: "Email"; description: "[email]"; Btn { kind: "ghost"; size: "small"; text: "Change" } }
                SettingRow { label: "Password"; description: "Last changed [date]"; Btn { kind: "ghost"; size: "small"; text: "Change" } }
                SettingRow {
                    label: "Sign out"; description: "Downloads stay on this computer."; showDivider: false
                    Btn { kind: "danger"; size: "small"; text: "Sign out"; onClicked: section.confirmSignOut = true }
                }
                // Inline confirmation
                Rectangle {
                    visible: section.confirmSignOut
                    Layout.fillWidth: true
                    Layout.topMargin: 10
                    implicitHeight: confirm.implicitHeight + 28
                    radius: 12
                    color: Theme.errorSoft
                    border.color: Theme.errorBorder
                    ColumnLayout {
                        id: confirm
                        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                        spacing: 10
                        Txt { Layout.fillWidth: true; text: "Sign out of manga-dl on this computer?"; font.weight: Font.Bold }
                        Row {
                            spacing: 8
                            // TODO(backend): clear the session.
                            Btn { kind: "danger"; size: "small"; text: "Sign out"; onClicked: Nav.go("Login") }
                            Btn { kind: "ghost"; size: "small"; text: "Cancel"; onClicked: section.confirmSignOut = false }
                        }
                    }
                }
            }
        ]
    }
}
