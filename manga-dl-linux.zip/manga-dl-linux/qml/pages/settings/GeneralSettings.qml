import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

SettingsSection {
    title: "General"
    caption: "Look, desktop behaviour and your manga-dl server."

    TwoColumns {
        leftCards: [
            SettingsCard {
                heading: "Appearance"
                SettingRow {
                    label: "Theme"; description: "manga-dl is designed dark-first."
                    below: [ Segmented { model: ["Dark", "AMOLED", "System"] } ]
                }
                SettingRow {
                    label: "Accent colour"; description: "Buttons, progress and highlights."
                    below: [
                        Row {
                            spacing: 10
                            Repeater {
                                model: Theme.accents
                                AbstractButton {
                                    required property var modelData
                                    readonly property bool current: Theme.accentName === modelData.name
                                    width: 40; height: 40
                                    Accessible.name: modelData.name
                                    Accessible.checked: current
                                    ToolTip.visible: hovered
                                    ToolTip.text: modelData.name
                                    hoverEnabled: true
                                    onClicked: Theme.setAccent(modelData.name)
                                    background: Rectangle {
                                        radius: 20
                                        color: "transparent"
                                        border.width: parent.current || parent.visualFocus ? 2 : 0
                                        border.color: parent.modelData.main
                                        Rectangle { anchors.centerIn: parent; width: 30; height: 30; radius: 15; color: parent.parent.modelData.main }
                                    }
                                }
                            }
                        }
                    ]
                }
                SettingRow {
                    label: "Ambilight"; description: "Tint the reader and detail pages with the cover's colour."; showDivider: false
                    MdSwitch { checked: true }
                }
            },
            SettingsCard {
                heading: "Connection"
                spacing: 14
                LabeledField { label: "Server URL"; text: "http://localhost:4567" }
                LabeledField { label: "API key"; text: "placeholder-key"; password: true }
                Row {
                    spacing: 12
                    // TODO(backend): ping the server.
                    Btn { kind: "ghost"; text: "Test connection"; onClicked: result.visible = true }
                    Row {
                        id: result
                        visible: false
                        spacing: 6
                        anchors.verticalCenter: parent.verticalCenter
                        Icon { name: "Check"; size: 16; color: Theme.successText }
                        Txt { text: "Connected · [latency] ms"; font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.successText }
                    }
                }
            }
        ]
        rightCards: [
            SettingsCard {
                heading: "Desktop"
                SettingRow { label: "Launch on startup"; description: "Start manga-dl when you log in."; MdSwitch {} }
                SettingRow { label: "Keep running in tray"; description: "Closing the window keeps downloads going."; MdSwitch { checked: true } }
                SettingRow { label: "Desktop notifications"; description: "New chapters and finished downloads."; MdSwitch { checked: true } }
                SettingRow { label: "Discord Rich Presence"; description: "Show what you're reading on Discord."; showDivider: false; MdSwitch {} }
            },
            SettingsCard {
                heading: "Behaviour"
                SettingRow { label: "Incognito mode"; description: "Pause history and tracker sync while it's on."; MdSwitch {} }
                SettingRow { label: "Auto-download new chapters"; description: "For manga in your library."; showDivider: false; MdSwitch { checked: true } }
            }
        ]
    }
}
