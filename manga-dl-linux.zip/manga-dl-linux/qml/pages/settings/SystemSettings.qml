import QtQuick
import QtQuick.Layouts
import MangaDl

SettingsSection {
    title: "System & backup"
    caption: "Storage, backups, servers and app updates."

    TwoColumns {
        leftCards: [
            SettingsCard {
                heading: "Storage"
                RowLayout {
                    Layout.fillWidth: true
                    Layout.topMargin: 4
                    Txt { text: "[n] GB used"; font.pixelSize: 20; font.weight: Font.ExtraBold; Layout.fillWidth: true }
                    Caption { text: "of [n] GB free" }
                }
                Progress { Layout.fillWidth: true; Layout.topMargin: 8; height: 8; value: 0.42 }
                Row {
                    Layout.topMargin: 10
                    Layout.bottomMargin: 6
                    spacing: 16
                    Row { spacing: 6; Rectangle { width: 8; height: 8; radius: 4; color: Theme.accent; anchors.verticalCenter: parent.verticalCenter } Caption { text: "Downloads [n] GB" } }
                    Row { spacing: 6; Rectangle { width: 8; height: 8; radius: 4; color: Theme.fgFaint; anchors.verticalCenter: parent.verticalCenter } Caption { text: "Cache [n] MB" } }
                }
                // TODO(backend): folder picker, cache clearing.
                SettingRow { label: "Download location"; description: "~/manga-library"; Btn { kind: "ghost"; size: "small"; text: "Change" } }
                SettingRow { label: "Clear image cache"; description: "Covers and pages you've read online."; showDivider: false; Btn { kind: "ghost"; size: "small"; text: "Clear"; onClicked: Nav.toast("Image cache cleared") } }
            },
            SettingsCard {
                heading: "Sync"
                SettingRow { label: "Sync library"; description: "Across every device signed in to your account."; MdSwitch { checked: true } }
                SettingRow { label: "Sync reading progress"; MdSwitch { checked: true } }
                SettingRow { label: "Sync settings"; showDivider: false; MdSwitch {} }
            }
        ]
        rightCards: [
            SettingsCard {
                heading: "Backup"
                // TODO(backend): create / restore backups.
                SettingRow { label: "Create backup"; description: "Library, categories, progress and settings."; Btn { size: "small"; text: "Create"; onClicked: Nav.toast("Backup created") } }
                SettingRow { label: "Restore backup"; description: "From a .mangadl or Tachiyomi backup file."; Btn { kind: "ghost"; size: "small"; text: "Restore" } }
                SettingRow {
                    label: "Automatic backups"; description: "Last backup [date]"; showDivider: false
                    MdCombo { model: ["Off", "Daily", "Weekly", "Monthly"]; currentIndex: 2; implicitWidth: 130; Accessible.name: "Automatic backups" }
                }
            },
            SettingsCard {
                heading: "Servers"
                SettingRow {
                    label: "Local server"; description: "http://localhost:4567 · running"
                    Rectangle {
                        width: online.implicitWidth + 20; height: 24; radius: 12; color: Theme.successSoft
                        Txt { id: online; anchors.centerIn: parent; text: "Online"; font.pixelSize: 12; font.weight: Font.Bold; color: Theme.successText }
                    }
                }
                SettingRow { label: "Remote servers"; description: "Add another manga-dl server to read from."; showDivider: false; Btn { kind: "ghost"; size: "small"; text: "Add server" } }
            }
        ]
    }

    // About
    Card {
        width: parent.width
        kind: "faint"
        RowLayout {
            Layout.fillWidth: true
            spacing: 20
            Image { source: "qrc:/qt/qml/MangaDl/assets/icons/manga-dl.png"; sourceSize: Qt.size(48, 48); Layout.preferredWidth: 48; Layout.preferredHeight: 48 }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                DisplayText { text: "manga-dl"; font.pixelSize: 22 }
                Caption { Layout.fillWidth: true; text: "Version " + AppInfo.version + " · update [x.y.z] ready to install"; font.pixelSize: 13 }
                Row {
                    Layout.topMargin: 8
                    spacing: 10
                    MdSwitch { checked: true; Accessible.name: "Install updates automatically" }
                    Txt { text: "Install updates automatically"; font.pixelSize: 13; color: Theme.fgSoft; anchors.verticalCenter: parent.verticalCenter }
                }
            }
            Btn { kind: "ghost"; text: "Release notes" }
            Btn { text: "Restart & Install"; onClicked: Nav.showUpdateDialog() }
        }
    }
}
