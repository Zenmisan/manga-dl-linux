import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

// Library: continue-reading cards, category chips and the cover grid.
Item {
    PageScroll {
        anchors.fill: parent

        // Header
        RowLayout {
            width: parent.width
            spacing: 16
            PageTitle { text: "Library"; Layout.fillWidth: true }
            SearchField { Layout.preferredWidth: 320; placeholderText: "Search library   Ctrl K" }
            Btn { kind: "ghost"; text: "Sort: Last read"; iconName: "Sort" }
            // TODO(backend): refresh every source.
            Btn { text: "Update Library"; iconName: "Refresh"; onClicked: Nav.toast("Checking 42 manga for new chapters") }
        }

        // Continue reading
        Column {
            width: parent.width
            spacing: 12
            Eyebrow { text: "Continue reading" }
            AutoGrid {
                width: parent.width
                minItemWidth: 280
                maxColumns: 3
                spacing: 16
                model: Sample.continueReading
                delegate: Clickable {
                    required property var modelData
                    width: parent.cellWidth
                    height: 110
                    radius: 16
                    fill: Theme.surfaceRaised
                    Accessible.name: "Resume " + modelData.manga.title
                    onClicked: Nav.open("Reader", { manga: modelData.manga })
                    Rectangle {   // border
                        width: parent.width; height: parent.height; radius: 16
                        color: "transparent"; border.color: Theme.dividerStrong
                    }
                    RowLayout {
                        width: parent.width; height: parent.height
                        anchors.margins: 12
                        spacing: 14
                        CoverArt { Layout.leftMargin: 12; width: 56; height: 84; radius: 8; cover: modelData.manga.cover }
                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.rightMargin: 12
                            spacing: 6
                            ItemTitle { Layout.fillWidth: true; text: modelData.manga.title }
                            Caption { Layout.fillWidth: true; text: modelData.where }
                            Progress { Layout.fillWidth: true; value: modelData.progress }
                        }
                    }
                }
            }
        }

        // Categories
        Row {
            spacing: 8
            ButtonGroup { id: categories }
            Repeater {
                model: Sample.categories
                Chip { required property string modelData; required property int index; text: modelData; checked: index === 0; ButtonGroup.group: categories }
            }
        }

        // Covers: 7 across at 1440 px, reflows with the window.
        AutoGrid {
            width: parent.width
            minItemWidth: 140
            spacing: 20
            model: Sample.library
            delegate: CoverTile { required property var modelData; width: parent.cellWidth; manga: modelData }
        }
    }
}
