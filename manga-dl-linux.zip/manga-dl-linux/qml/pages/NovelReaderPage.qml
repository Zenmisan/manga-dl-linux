import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

// Web-novel reader: chapter list on the left, article in a comfortable column,
// "Reading Settings" popover for font, size and theme.
Rectangle {
    id: page
    property string fontFamily: Theme.serif
    property int fontSize: 20
    property color paper: "#0D0D0D"
    property color ink: "#DBFFFFFF"
    color: Theme.novelBg

    readonly property var themes: [
        { name: "Dark", bg: "#0D0D0D", fg: "#DBFFFFFF" },
        { name: "Black", bg: "#000000", fg: "#DBFFFFFF" },
        { name: "Sepia", bg: "#E8DCC4", fg: "#3B2F22" },
        { name: "Light", bg: "#F5F5F2", fg: "#1F1F1F" }
    ]

    focus: true
    Keys.onEscapePressed: Nav.back()

    // Top bar
    Rectangle {
        id: topBar
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: 56
        color: "#EB080808"
        z: 2
        HairLine { anchors.bottom: parent.bottom; width: parent.width; color: Theme.dividerStrong }
        RowLayout {
            anchors { fill: parent; leftMargin: 16; rightMargin: 16 }
            spacing: 12
            Btn { kind: "icon"; iconName: "Back"; Accessible.name: "Close reader"; onClicked: Nav.back() }
            Txt {
                Layout.fillWidth: true
                textFormat: Text.StyledText
                text: "<b>[Novel title]</b><font color='" + Theme.fgSubtle + "'> · Ch. 12 · 34%</font>"
            }
            Btn {
                id: settingsButton
                kind: "ghost"; size: "small"
                text: "Reading Settings"
                Accessible.name: "Reading settings"
                onClicked: settings.opened ? settings.close() : settings.open()
                leftPadding: 40
                Txt { text: "Aa"; font.family: Theme.serif; font.pixelSize: 14; x: 14; anchors.verticalCenter: parent.verticalCenter }
            }
        }
    }

    Popup {
        id: settings
        parent: settingsButton
        x: settingsButton.width - width
        y: settingsButton.height + 8
        width: 380
        padding: 20
        background: Rectangle { radius: 16; color: Theme.panel; border.color: Theme.track }
        contentItem: ColumnLayout {
            spacing: 18
            ColumnLayout {
                spacing: 10
                Eyebrow { text: "Font"; muted: true }
                RowLayout {
                    spacing: 8
                    ButtonGroup { id: fontGroup }
                    OptionButton { Layout.fillWidth: true; text: "Serif"; font.family: Theme.serif; font.pixelSize: 15; checked: page.fontFamily === Theme.serif; ButtonGroup.group: fontGroup; onClicked: page.fontFamily = Theme.serif }
                    OptionButton { Layout.fillWidth: true; text: "Sans"; checked: page.fontFamily === Theme.body; ButtonGroup.group: fontGroup; onClicked: page.fontFamily = Theme.body }
                }
            }
            ColumnLayout {
                spacing: 6
                RowLayout {
                    Eyebrow { text: "Size"; muted: true; Layout.fillWidth: true }
                    Caption { text: page.fontSize + "px" }
                }
                MdSlider { Layout.fillWidth: true; from: 14; to: 28; value: page.fontSize; onMoved: page.fontSize = value; Accessible.name: "Text size" }
            }
            ColumnLayout {
                spacing: 10
                Eyebrow { text: "Theme"; muted: true }
                Row {
                    spacing: 10
                    Repeater {
                        model: page.themes
                        AbstractButton {
                            required property var modelData
                            width: 44; height: 44
                            Accessible.name: modelData.name + " theme"
                            onClicked: { page.paper = modelData.bg; page.ink = modelData.fg }
                            background: Rectangle {
                                radius: 22
                                color: modelData.bg
                                border.width: Qt.colorEqual(page.paper, modelData.bg) ? 2 : 1
                                border.color: Qt.colorEqual(page.paper, modelData.bg) ? Theme.accent : "#33FFFFFF"
                            }
                        }
                    }
                }
            }
        }
    }

    // Chapter list
    Rectangle {
        id: list
        anchors { left: parent.left; top: topBar.bottom; bottom: parent.bottom }
        width: 300
        color: "#0A0A0A"
        Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: Theme.dividerStrong }
        PageScroll {
            anchors.fill: parent
            padding: 12
            topPadding: 20
            spacing: 2
            Eyebrow { text: "Chapters"; muted: true; leftPadding: 12; bottomPadding: 10 }
            Repeater {
                // TODO(backend): load the novel's chapter list.
                model: 11
                NavItem {
                    required property int index
                    readonly property int number: index + 8
                    width: parent.width
                    height: 42
                    text: "Ch. " + number + " · [title]"
                    font.pixelSize: 13
                    selected: number === 12
                    opacity: number < 12 ? 0.5 : 1
                }
            }
        }
    }

    // Article
    Rectangle {
        anchors { left: list.right; right: parent.right; top: topBar.bottom; bottom: parent.bottom }
        color: page.paper
        PageScroll {
            anchors.fill: parent
            padding: Math.max(40, (width - 680) / 2)
            topPadding: 56
            bottomPadding: 56
            spacing: 22
            Txt { text: "Chapter 12 · [chapter title]"; font.pixelSize: 13; font.weight: Font.ExtraBold; font.letterSpacing: 2; font.capitalization: Font.AllUppercase; color: Theme.fgSubtle; bottomPadding: 6 }
            // Replace with the chapter's paragraphs.
            Repeater {
                model: [
                    "[Chapter text loads here in the reading font, centred in a comfortable column. The side list jumps between chapters without leaving the page.]",
                    "[Font, size, line height, column width and theme come from Reading Settings. Arrow keys and space scroll; N and P jump chapters.]",
                    "[Progress saves as you scroll and syncs like manga progress.]"
                ]
                Text {
                    required property string modelData
                    width: parent.width
                    text: modelData
                    wrapMode: Text.Wrap
                    font.family: page.fontFamily
                    font.pixelSize: page.fontSize
                    lineHeightMode: Text.FixedHeight
                    lineHeight: Math.round(page.fontSize * 1.75)
                    color: page.ink
                }
            }
        }
    }
}
