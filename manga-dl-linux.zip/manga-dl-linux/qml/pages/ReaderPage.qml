import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import QtQuick.Window
import MangaDl

// Manga reader. Opens as a two-page spread with the settings panel; pass
// { layout: "single" } for the single-page layout with side buttons and a page bar.
// Keys: ← → / Space turn pages, F fullscreen, Esc leaves fullscreen or closes.
Rectangle {
    id: page
    property var manga: Sample.featured
    property string layout: "spread"
    readonly property bool spread: layout !== "single"
    property int current: 14
    readonly property int total: 38
    property bool bookmarked: false
    property bool showSettings: layout !== "single"

    color: Theme.readerBg
    focus: true
    Component.onCompleted: forceActiveFocus()

    function go(delta) { current = Math.max(1, Math.min(total, current + delta * (spread ? 2 : 1))) }
    function toggleFullscreen() {
        const w = Window.window
        w.visibility = w.visibility === Window.FullScreen ? Window.Windowed : Window.FullScreen
    }

    Keys.onPressed: e => {
        if (e.key === Qt.Key_Right || e.key === Qt.Key_Space) { go(1); e.accepted = true }
        else if (e.key === Qt.Key_Left) { go(-1); e.accepted = true }
        else if (e.key === Qt.Key_F) { toggleFullscreen(); e.accepted = true }
        else if (e.key === Qt.Key_Escape) {
            if (Window.window.visibility === Window.FullScreen) toggleFullscreen()
            else Nav.back()
            e.accepted = true
        }
    }

    // ===== Top bar =====
    Rectangle {
        id: topBar
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: 56
        color: "#EB080808"
        z: 2
        HairLine { anchors.bottom: parent.bottom; width: parent.width; color: Theme.dividerStrong }
        RowLayout {
            anchors { fill: parent; leftMargin: 16; rightMargin: 16 }
            spacing: 12
            Btn { kind: "icon"; iconName: "Back"; Accessible.name: "Close reader"; onClicked: Nav.back() }
            Txt {
                Layout.fillWidth: true
                textFormat: Text.StyledText
                text: "<b>" + page.manga.title + "</b><font color='" + Theme.fgSubtle + "'>  ·  Ch. 48 · [Chapter title]</font>"
                elide: Text.ElideRight
            }
            Segmented {
                model: ["Single", "Spread"]
                currentIndex: page.spread ? 1 : 0
                onActivated: index => page.layout = index === 1 ? "spread" : "single"
            }
            Btn { kind: "ghost"; size: "small"; text: "Prev ch."; font.weight: Font.Bold }
            Txt {
                Layout.minimumWidth: 72
                horizontalAlignment: Text.AlignHCenter
                font.pixelSize: 13; font.weight: Font.Bold
                text: page.spread ? page.current + "–" + Math.min(page.current + 1, page.total) + " / " + page.total : page.current + " / " + page.total
                Accessible.role: Accessible.StaticText
            }
            Btn { kind: "ghost"; size: "small"; text: "Next ch."; font.weight: Font.Bold }
            Btn {
                kind: "icon"; iconName: page.bookmarked ? "BookmarkFilled" : "Bookmark"
                textColor: page.bookmarked ? Theme.accentLight : Theme.fg
                Accessible.name: "Bookmark page"
                onClicked: page.bookmarked = !page.bookmarked
            }
            Btn { kind: "icon"; iconName: "Fullscreen"; Accessible.name: "Toggle fullscreen"; onClicked: page.toggleFullscreen() }
            IconToggle { iconName: "Sliders"; checked: page.showSettings; onToggled: page.showSettings = checked; Accessible.name: "Reader settings" }
        }
    }

    // ===== Stage =====
    Item {
        id: stage
        anchors { left: parent.left; top: topBar.bottom; bottom: parent.bottom; right: panel.visible ? panel.left : parent.right }

        // Two-page spread (right-to-left: the next page sits on the left)
        Row {
            visible: page.spread
            anchors.centerIn: parent
            spacing: 2
            readonly property real scale: Math.min(1, (stage.width - 40) / 1042, (stage.height - 40) / 760)
            PagePlaceholder { width: 520 * parent.scale; height: 760 * parent.scale; label: "[Page " + Math.min(page.current + 1, page.total) + "]" }
            PagePlaceholder { width: 520 * parent.scale; height: 760 * parent.scale; label: "[Page " + page.current + "]" }
        }
        MouseArea {
            visible: page.spread
            anchors.fill: parent
            // Click zones: left half goes forward (RTL), right half goes back.
            onClicked: m => page.go(m.x < width / 2 ? 1 : -1)
        }

        // Single page with side buttons and a floating page bar
        Item {
            visible: !page.spread
            anchors.fill: parent
            RowLayout {
                anchors { fill: parent; topMargin: 16; bottomMargin: 96 }
                spacing: 24
                Item { Layout.fillWidth: true }
                Btn {
                    kind: "icon"; iconName: "Back"; iconSize: 24; textColor: Theme.fgSoft; fillColor: Theme.surface
                    implicitWidth: 56; implicitHeight: 96; radius: 14
                    Accessible.name: "Previous page"; onClicked: page.go(-1)
                }
                PagePlaceholder {
                    readonly property real s: Math.min(1, parent.height / 684)
                    Layout.preferredWidth: 476 * s
                    Layout.preferredHeight: 684 * s
                    label: "[Page " + page.current + "]"
                }
                Btn {
                    kind: "icon"; iconName: "ChevronRight"; iconSize: 24; textColor: Theme.fgSoft; fillColor: Theme.surface
                    implicitWidth: 56; implicitHeight: 96; radius: 14
                    Accessible.name: "Next page"; onClicked: page.go(1)
                }
                Item { Layout.fillWidth: true }
            }
            Rectangle {
                anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 24 }
                width: Math.min(720, parent.width - 48)
                height: 58
                radius: height / 2
                color: "#F00E0E0E"
                border.color: Theme.dividerStrong
                RowLayout {
                    anchors { fill: parent; margins: 8 }
                    spacing: 12
                    Btn { kind: "ghost"; size: "pill"; text: "Prev Ch."; borderColor: "transparent"; fillColor: Theme.surfaceHigh; implicitHeight: 40 }
                    Txt { text: page.current; Layout.minimumWidth: 24; horizontalAlignment: Text.AlignHCenter; font.pixelSize: 13; font.weight: Font.ExtraBold }
                    MdSlider {
                        Layout.fillWidth: true
                        from: 1; to: page.total
                        value: page.current
                        onMoved: page.current = value
                        Accessible.name: "Page"
                    }
                    Txt { text: page.total; Layout.minimumWidth: 24; horizontalAlignment: Text.AlignHCenter; font.pixelSize: 13; font.weight: Font.Bold; color: Theme.fgSubtle }
                    Btn { size: "pill"; text: "Next Ch."; implicitHeight: 40 }
                }
            }
        }
    }

    // ===== Settings panel =====
    Rectangle {
        id: panel
        visible: page.showSettings
        anchors { right: parent.right; top: topBar.bottom; bottom: parent.bottom }
        width: 340
        color: Theme.panel
        Rectangle { width: 1; height: parent.height; color: Theme.dividerStrong }

        PageScroll {
            anchors.fill: parent
            padding: 24
            topPadding: 24
            bottomPadding: 24

            DisplayText { text: "Reader"; font.pixelSize: 24 }

            Column {
                width: parent.width
                spacing: 10
                Eyebrow { text: "Reading mode"; muted: true }
                ButtonGroup { id: mode }
                Grid {
                    width: parent.width
                    columns: 2
                    spacing: 8
                    Repeater {
                        model: ["LTR pager", "RTL pager", "Webtoon", "Vertical"]
                        OptionButton {
                            required property string modelData
                            width: (parent.width - 8) / 2
                            text: modelData
                            checked: modelData === "RTL pager"
                            ButtonGroup.group: mode
                        }
                    }
                }
            }

            Column {
                width: parent.width
                Repeater {
                    model: [["Dual-page spread", "dual"], ["Crop borders", ""], ["Tap zones", "on"]]
                    Item {
                        required property var modelData
                        width: parent.width
                        height: 44
                        Txt { text: modelData[0]; font.weight: Font.DemiBold; anchors.verticalCenter: parent.verticalCenter }
                        MdSwitch {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            Accessible.name: modelData[0]
                            checked: modelData[1] === "dual" ? page.spread : modelData[1] === "on"
                            onToggled: if (modelData[1] === "dual") page.layout = checked ? "spread" : "single"
                        }
                    }
                }
            }

            Column {
                width: parent.width
                spacing: 14
                Eyebrow { text: "Image filters"; muted: true }
                Repeater {
                    model: ["Brightness", "Contrast"]
                    Column {
                        id: filter
                        required property string modelData
                        width: parent.width
                        spacing: 4
                        Item {
                            width: parent.width; height: 18
                            Txt { text: filter.modelData; font.pixelSize: 13 }
                            Txt { anchors.right: parent.right; text: Math.round(slider.value) + "%"; font.pixelSize: 13; color: Theme.fgSubtle }
                        }
                        MdSlider { id: slider; width: parent.width; from: 50; to: 150; value: 100; Accessible.name: filter.modelData }
                    }
                }
                Row {
                    spacing: 8
                    Chip { small: true; text: "Grayscale" }
                    Chip { small: true; text: "Invert" }
                    Chip { small: true; text: "Sepia" }
                }
            }
        }
    }
}
