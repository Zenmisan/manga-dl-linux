import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

// Manga detail: hero tinted with the cover colour (ambilight) and the chapter table.
// Open with { manga: <manga map> }.
Item {
    id: page
    property var manga: Sample.featured
    property bool inLibrary: !!manga.inLibrary

    function shade(c, f) { const k = Qt.color(c); return Qt.rgba(k.r * f, k.g * f, k.b * f, 1) }

    component HeroButton: Btn {
        kind: "ghost"; borderColor: "transparent"; fillColor: Theme.darkChip
        implicitHeight: 46; fontSize: 14
    }

    PageScroll {
        anchors.fill: parent
        padding: 0
        topPadding: 0
        spacing: 0

        // Hero band
        Rectangle {
            width: parent.width
            height: heroRow.implicitHeight + 52
            color: page.manga.cover
            Rectangle {
                anchors.fill: parent
                gradient: Gradient {
                    GradientStop { position: 0.0; color: "transparent" }
                    GradientStop { position: 1.0; color: Theme.alpha(Theme.bg, 0x66) }
                }
            }
            RowLayout {
                id: heroRow
                anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 40; rightMargin: 40; topMargin: 24 }
                spacing: 32
                Rectangle {
                    Layout.alignment: Qt.AlignBottom
                    width: 200; height: 300; radius: 14
                    color: page.shade(page.manga.cover, 0.6)
                    border.color: Theme.line
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.alignment: Qt.AlignBottom
                    spacing: 12
                    Btn { kind: "link"; text: "Library"; iconName: "Back"; iconSize: 14; textColor: Theme.fgSoft; leftPadding: 0; font.weight: Font.DemiBold; onClicked: Nav.back() }
                    DisplayText { Layout.fillWidth: true; text: page.manga.title; font.pixelSize: 64; wrapMode: Text.Wrap }
                    Txt { Layout.fillWidth: true; text: "[Author name] · Ongoing · " + page.manga.source; color: Theme.fgStrong }
                    Txt {
                        Layout.fillWidth: true
                        Layout.maximumWidth: 680
                        text: "[Synopsis — pulled from the source. Shows up to four lines on desktop with a Show more link when it runs longer.]"
                        color: Theme.fgStrong
                        wrapMode: Text.Wrap; maximumLineCount: 4; elide: Text.ElideRight
                        lineHeightMode: Text.FixedHeight; lineHeight: 22
                    }
                    Row {
                        Layout.topMargin: 6
                        spacing: 10
                        Btn { text: "Resume Ch. 48"; iconName: "Play"; implicitHeight: 46; fontSize: 14; leftPadding: 22; rightPadding: 22; onClicked: Nav.open("Reader", { manga: page.manga }) }
                        // TODO(backend): add/remove from library.
                        HeroButton { text: page.inLibrary ? "In Library" : "Add to Library"; iconName: page.inLibrary ? "Check" : "Plus"; onClicked: page.inLibrary = !page.inLibrary }
                        HeroButton { text: "Track"; iconName: "Track" }
                        HeroButton { text: "Download"; iconName: "Download" }
                        HeroButton { text: "Migrate"; iconName: "Refresh" }
                    }
                }
            }
        }

        // Chapter filters
        RowLayout {
            x: 40
            width: parent.width - 80
            height: 56
            spacing: 12
            SectionTitle { text: "96 chapters"; Layout.fillWidth: true; Layout.alignment: Qt.AlignBottom }
            Chip { small: true; text: "Unread"; Layout.alignment: Qt.AlignBottom }
            Chip { small: true; text: "Downloaded"; Layout.alignment: Qt.AlignBottom }
            Btn { kind: "ghost"; size: "pill"; text: "Newest first"; iconName: "Sort"; iconSize: 14; Layout.alignment: Qt.AlignBottom }
        }

        // Chapter table
        Column {
            x: 40
            width: parent.width - 80
            topPadding: 12
            bottomPadding: 40
            RowLayout {
                width: parent.width
                height: 36
                spacing: 16
                TableHeader { text: "No."; Layout.preferredWidth: 90; Layout.leftMargin: 12 }
                TableHeader { text: "Title"; Layout.fillWidth: true }
                TableHeader { text: "Released"; Layout.preferredWidth: 160 }
                TableHeader { text: "Group"; Layout.preferredWidth: 160 }
                TableHeader { text: "Status"; Layout.preferredWidth: 120; horizontalAlignment: Text.AlignRight; Layout.rightMargin: 12 }
            }
            Repeater {
                model: Sample.chapters
                delegate: Clickable {
                    required property var modelData
                    width: parent.width
                    height: 48
                    radius: 0
                    Accessible.name: "Chapter " + modelData.number
                    onClicked: Nav.open("Reader", { manga: page.manga })
                    HairLine { width: parent.width }
                    RowLayout {
                        width: parent.width; height: parent.height
                        spacing: 16
                        opacity: modelData.read ? 0.5 : 1
                        Txt { text: modelData.number; font.weight: Font.Bold; Layout.preferredWidth: 90; Layout.leftMargin: 12 }
                        Txt { text: modelData.title; Layout.fillWidth: true; elide: Text.ElideRight }
                        Txt { text: modelData.released; color: Theme.fgSubtle; Layout.preferredWidth: 160 }
                        Txt { text: modelData.group; color: Theme.fgSubtle; Layout.preferredWidth: 160 }
                        Txt {
                            text: modelData.status
                            font.pixelSize: 12; font.weight: Font.Bold
                            color: modelData.status.startsWith("Page") ? Theme.accentLight : Theme.fgSoft
                            horizontalAlignment: Text.AlignRight
                            Layout.preferredWidth: 120; Layout.rightMargin: 12
                        }
                    }
                }
            }
        }
    }
}
