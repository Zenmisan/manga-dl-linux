import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

// Reading history: two columns of resume cards.
Item {
    PageScroll {
        anchors.fill: parent
        spacing: 18

        RowLayout {
            width: parent.width
            spacing: 12
            PageTitle { text: "History"; Layout.fillWidth: true }
            SearchField { Layout.preferredWidth: 300; placeholderText: "Search history" }
            Btn { kind: "danger"; text: "Clear History" }
        }

        Row {
            spacing: 8
            ButtonGroup { id: range }
            Repeater {
                model: ["Today", "This week", "This month", "All time"]
                Chip { required property string modelData; text: modelData; checked: modelData === "This week"; ButtonGroup.group: range }
            }
        }

        AutoGrid {
            width: parent.width
            minItemWidth: 420
            maxColumns: 2
            spacing: 12
            model: Sample.history
            delegate: Rectangle {
                required property var modelData
                width: parent.cellWidth
                height: 110
                radius: 14
                color: Theme.surface4
                border.color: Theme.dividerStrong
                RowLayout {
                    anchors { fill: parent; margins: 12 }
                    spacing: 16
                    CoverArt { width: 56; height: 84; radius: 8; cover: modelData.manga.cover }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 4
                        ItemTitle { Layout.fillWidth: true; text: modelData.manga.title }
                        Txt { Layout.fillWidth: true; text: modelData.where; font.pixelSize: 13; color: Theme.fgSoft }
                        Txt { Layout.fillWidth: true; text: modelData.when; font.pixelSize: 12; color: Theme.fgFaint }
                    }
                    Btn { kind: "icon"; iconName: "Close"; iconSize: 18; textColor: Theme.fgSubtle; implicitHeight: 40; Accessible.name: "Remove from history" }
                    Btn { text: "Resume"; implicitHeight: 40; radius: 10; leftPadding: 16; rightPadding: 16; onClicked: Nav.open("Reader", { manga: modelData.manga }) }
                }
            }
        }
    }
}
