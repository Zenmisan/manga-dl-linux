import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

// Global search across sources, with a filter panel on the right.
Item {
    PageScroll {
        anchors { left: parent.left; top: parent.top; bottom: parent.bottom; right: filters.left }
        spacing: 16

        Item {
            width: parent.width
            height: search.height
            SearchField { id: search; width: parent.width; large: true; text: "crown"; placeholderText: "Search all sources" }
            Caption { text: "Searching 6 sources"; anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter } }
        }

        Tabs { width: parent.width; model: ["Manga", "Web Novels", "Readers"] }

        Repeater {
            model: Sample.searchResults
            delegate: Column {
                required property var modelData
                width: parent.width
                spacing: 10
                bottomPadding: 8
                RowLayout {
                    width: parent.width
                    spacing: 12
                    SectionTitle { text: modelData.source }
                    Caption { text: modelData.meta; Layout.fillWidth: true }
                    Btn { kind: "link"; text: "See All"; fontSize: 13; onClicked: Nav.open("BrowseSource", { source: modelData.source }) }
                }
                AutoGrid {
                    width: parent.width
                    minItemWidth: 110
                    maxColumns: 7
                    spacing: 16
                    model: modelData.results
                    delegate: ResultTile { required property var modelData; width: parent.cellWidth; manga: modelData }
                }
            }
        }

        // Still searching
        Column {
            width: parent.width
            spacing: 10
            RowLayout {
                width: parent.width
                SectionTitle { text: "Asura Scans"; Layout.fillWidth: true }
                Caption { text: "Searching…" }
            }
            Row {
                spacing: 16
                Repeater { model: 3; Rectangle { width: 110; height: 165; radius: 10; color: Theme.surfaceRaised } }
            }
        }
    }

    // Filters
    Rectangle {
        id: filters
        width: 300
        anchors { top: parent.top; bottom: parent.bottom; right: parent.right }
        color: Theme.navBg
        Rectangle { width: 1; height: parent.height; color: Theme.dividerStrong }

        ColumnLayout {
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 24; topMargin: 28 }
            spacing: 20
            SectionTitle { Layout.fillWidth: true; text: "Search filters" }
            ColumnLayout {
                spacing: 2
                Eyebrow { text: "Sources"; muted: true; Layout.bottomMargin: 6 }
                CheckRow { text: "MangaDex"; checked: true }
                CheckRow { text: "MangaKatana"; checked: true }
                CheckRow { text: "Asura Scans"; checked: true }
                CheckRow { text: "Komga" }
            }
            ColumnLayout {
                spacing: 10
                Eyebrow { text: "Status"; muted: true }
                Row {
                    spacing: 6
                    ButtonGroup { id: status }
                    Chip { small: true; leftPadding: 12; text: "Any"; checked: true; ButtonGroup.group: status }
                    Chip { small: true; leftPadding: 12; text: "Ongoing"; ButtonGroup.group: status }
                    Chip { small: true; leftPadding: 12; text: "Completed"; ButtonGroup.group: status }
                }
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 8
                Eyebrow { text: "Sort by"; muted: true }
                MdCombo { Layout.fillWidth: true; model: ["Relevance", "Latest update", "Title A–Z"]; Accessible.name: "Sort by" }
            }
        }
        RowLayout {
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 24; bottomMargin: 28 }
            spacing: 8
            Btn { Layout.fillWidth: true; kind: "ghost"; text: "Reset"; implicitHeight: 44 }
            // TODO(backend): run the search with these filters.
            Btn { Layout.fillWidth: true; text: "Apply"; implicitHeight: 44 }
        }
    }
}
