import QtQuick
import QtQuick.Layouts
import MangaDl

// Sign in.
AuthLayout {
    title: "Sign in"
    titleSize: 132
    subtitle: "Sync your library, history and backups between this computer, your phone and the web."

    LabeledField { label: "Email"; placeholderText: "you@example.com" }
    LabeledField { label: "Password"; placeholderText: "Your password"; password: true }
    RowLayout {
        Layout.fillWidth: true
        CheckRow { text: "Stay signed in"; checked: true; font.pixelSize: 13; Layout.fillWidth: true }
        Btn { kind: "link"; text: "Forgot password?"; fontSize: 13; onClicked: Nav.open("ForgotPassword") }
    }
    // TODO(backend): authenticate.
    Btn { Layout.fillWidth: true; size: "large"; text: "Sign In"; onClicked: Nav.home() }
    Btn { Layout.fillWidth: true; kind: "ghost"; size: "large"; text: "Use Without Account"; onClicked: Nav.home() }
    Row {
        Layout.topMargin: 8
        BodyMuted { text: "No account?"; anchors.verticalCenter: parent.verticalCenter }
        Btn { kind: "link"; text: "Create one"; onClicked: Nav.go("Register") }
    }
}
