import QtQuick
import QtQuick.Layouts
import MangaDl

// Download queue with a "save to" side panel.
Item {
    id: page
    property bool paused: false

    function stateText(s) { return s === "failed" ? Theme.errorText : s === "done" ? Theme.successText : Theme.fgMuted }
    function stateBar(s) { return s === "failed" ? Theme.errorBar : s === "done" ? Theme.success : s === "paused" ? Theme.fgFaint : Theme.accent }
    function stateAction(s) { return s === "failed" ? "Retry" : s === "paused" ? "Resume" : s === "done" ? "Remove" : "Pause" }
    function stateIcon(s) { return s === "failed" ? "Refresh" : s === "paused" ? "Play" : s === "done" ? "Close" : "Pause" }

    PageScroll {
        anchors.fill: parent

        RowLayout {
            width: parent.width
            spacing: 32

            ColumnLayout {
                Layout.fillWidth: true
                Layout.alignment: Qt.AlignTop
                spacing: 20

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10
                    PageTitle { text: "Downloads"; Layout.fillWidth: true }
                    Btn { kind: "ghost"; text: "Clear Finished" }
                    // TODO(backend): pause/resume the queue.
                    Btn { text: page.paused ? "Resume All" : "Pause All"; iconName: page.paused ? "Play" : "Pause"; onClicked: page.paused = !page.paused }
                }

                Tabs { Layout.fillWidth: true; model: ["Queue · 5", "Finished", "Failed · 1"] }

                Repeater {
                    model: Sample.downloads
                    delegate: Rectangle {
                        required property var modelData
                        Layout.fillWidth: true
                        height: 88
                        radius: 14
                        color: Theme.surface
                        border.color: Theme.dividerStrong
                        RowLayout {
                            anchors { fill: parent; leftMargin: 16; rightMargin: 16 }
                            spacing: 16
                            CoverArt { width: 40; height: 60; radius: 6; cover: modelData.manga.cover }
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 8
                                RowLayout {
                                    Layout.fillWidth: true
                                    Txt {
                                        Layout.fillWidth: true
                                        textFormat: Text.StyledText
                                        text: modelData.manga.title + "<font color='" + Theme.fgSubtle + "'> · " + modelData.chapter + "</font>"
                                        font.weight: Font.Bold
                                    }
                                    Txt { text: modelData.status; font.pixelSize: 12; font.weight: Font.Bold; color: page.stateText(modelData.state) }
                                }
                                Progress { Layout.fillWidth: true; value: modelData.progress; fill: page.stateBar(modelData.state) }
                            }
                            Btn {
                                kind: "icon"; iconName: page.stateIcon(modelData.state); iconSize: 18
                                fillColor: Theme.surfaceRaised
                                Accessible.name: page.stateAction(modelData.state)
                            }
                            Btn { kind: "icon"; iconName: "Close"; iconSize: 18; textColor: Theme.fgMuted; Accessible.name: "Cancel download"; visible: modelData.state !== "done" }
                        }
                    }
                }
            }

            Card {
                Layout.preferredWidth: 300
                Layout.alignment: Qt.AlignTop
                Layout.topMargin: 8
                kind: "list"
                padding: 20
                radius: 16
                spacing: 14
                Eyebrow { text: "Save to" }
                Txt { text: "~/manga-library"; font.pixelSize: 13; font.weight: Font.DemiBold }
                Btn { Layout.fillWidth: true; kind: "ghost"; text: "Change Folder"; iconName: "Folder"; implicitHeight: 40; radius: 10 }
                Repeater {
                    model: [["Format", "CBZ + ComicInfo"], ["Parallel downloads", "[n]"], ["Storage used", "—"]]
                    RowLayout {
                        required property var modelData
                        Layout.fillWidth: true
                        Txt { text: modelData[0]; font.pixelSize: 13; color: Theme.fgMuted; Layout.fillWidth: true }
                        Txt { text: modelData[1]; font.pixelSize: 13; font.weight: Font.DemiBold }
                    }
                }
            }
        }
    }
}
