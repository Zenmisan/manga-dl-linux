import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

// One source's catalogue. Open with { source: "MangaDex" }.
Item {
    id: page
    property string source: "MangaDex"

    component FilterChip: Rectangle {
        property string label
        height: 32
        width: row.implicitWidth + 16
        radius: 16
        color: Theme.accentMuted
        Row {
            id: row
            x: 12
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4
            Txt { text: label; font.pixelSize: 12; font.weight: Font.Bold; color: Theme.accentSoft; anchors.verticalCenter: parent.verticalCenter }
            Btn {
                kind: "icon"; iconName: "Close"; iconSize: 12; textColor: Theme.accentSoft
                implicitHeight: 24; radius: 12
                Accessible.name: "Remove " + label + " filter"
                onClicked: parent.parent.visible = false
            }
        }
    }

    PageScroll {
        anchors.fill: parent
        topPadding: 24
        spacing: 18

        Btn { kind: "link"; text: "Browse"; iconName: "Back"; iconSize: 14; textColor: Theme.fgMuted; fontSize: 13; leftPadding: 0; onClicked: Nav.back() }

        RowLayout {
            width: parent.width
            spacing: 12
            PageTitle { text: page.source; Layout.fillWidth: true }
            SearchField { Layout.preferredWidth: 300; placeholderText: "Search " + page.source }
            Btn { kind: "ghost"; text: "Open in Browser"; iconName: "Globe" }
            Btn { text: "Filters · 2"; iconName: "Filter" }
        }

        Row {
            spacing: 8
            ButtonGroup { id: order }
            Chip { text: "Popular"; checked: true; ButtonGroup.group: order }
            Chip { text: "Latest"; ButtonGroup.group: order }
            Rectangle { width: 1; height: 24; color: Theme.track; anchors.verticalCenter: parent.verticalCenter }
            FilterChip { label: "Fantasy"; anchors.verticalCenter: parent.verticalCenter }
            FilterChip { label: "Ongoing"; anchors.verticalCenter: parent.verticalCenter }
        }

        // 8 across at 1440 px
        AutoGrid {
            width: parent.width
            minItemWidth: 120
            spacing: 18
            model: Sample.browseCatalog
            delegate: ResultTile { required property var modelData; width: parent.cellWidth; manga: modelData; dimInLibrary: true }
        }
    }
}
