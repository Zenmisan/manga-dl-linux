import QtQuick
import QtQuick.Layouts
import MangaDl

// First run, step 2 of 3: optional backend connection.
Item {
    // Hero
    Item {
        id: hero
        width: parent.width / 2
        height: parent.height
        clip: true
        Bloom { anchors.fill: parent }
        Rectangle { anchors { top: parent.top; bottom: parent.bottom; right: parent.right } width: 1; color: Theme.dividerStrong }

        ColumnLayout {
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 64; topMargin: 72 }
            spacing: 20
            Eyebrow { text: "Welcome to manga-dl" }
            DisplayText { Layout.fillWidth: true; text: "Your manga, everywhere."; font.pixelSize: 104; wrapMode: Text.Wrap }
        }

        // Steps
        Column {
            anchors { left: parent.left; bottom: parent.bottom; leftMargin: 64; bottomMargin: 72 }
            spacing: 14
            Row {
                spacing: 14
                Rectangle {
                    width: 32; height: 32; radius: 16; color: Theme.successSoft
                    Icon { anchors.centerIn: parent; name: "Check"; size: 16; color: Theme.successText }
                }
                Txt { text: "Welcome"; font.pixelSize: 15; font.weight: Font.DemiBold; color: Theme.fgMuted; anchors.verticalCenter: parent.verticalCenter }
            }
            Row {
                spacing: 14
                Rectangle {
                    width: 32; height: 32; radius: 16; color: Theme.accent
                    Txt { anchors.centerIn: parent; text: "2"; font.pixelSize: 13; font.weight: Font.ExtraBold; color: Theme.white }
                }
                Txt { text: "Connect to backend"; font.pixelSize: 15; font.weight: Font.ExtraBold; anchors.verticalCenter: parent.verticalCenter }
            }
            Row {
                spacing: 14
                Rectangle {
                    width: 32; height: 32; radius: 16; color: "transparent"; border.color: Theme.switchOff
                    Txt { anchors.centerIn: parent; text: "3"; font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.fgSubtle }
                }
                Txt { text: "Library folder & account"; font.pixelSize: 15; font.weight: Font.DemiBold; color: Theme.fgSubtle; anchors.verticalCenter: parent.verticalCenter }
            }
        }
    }

    // Form
    Item {
        x: hero.width
        width: parent.width - hero.width
        height: parent.height

        ColumnLayout {
            anchors { left: parent.left; top: parent.top; leftMargin: 80; topMargin: 72 }
            width: Math.min(460, parent.width - 120)
            spacing: 24
            Txt { Layout.fillWidth: true; text: "Connect to backend"; font.pixelSize: 28; font.weight: Font.Black }
            BodyMuted {
                Layout.fillWidth: true
                font.pixelSize: 15; lineHeight: 23
                text: "The desktop app reads sources by itself. Add a backend only if you want sync and cloud backups. You can change this later in Settings."
            }
            LabeledField { label: "Backend URL"; text: "https://[your-server]:8000" }
            LabeledField { label: "API key (optional)"; text: "secretkey"; password: true }
            RowLayout {
                spacing: 12
                // TODO(backend): ping the server and show the real result.
                Btn { kind: "ghost"; text: "Test Connection"; implicitHeight: 44; onClicked: connected.visible = true }
                Row {
                    id: connected
                    spacing: 8
                    Icon { name: "Check"; size: 16; color: Theme.successText; anchors.verticalCenter: parent.verticalCenter }
                    Txt { text: "Connected"; font.pixelSize: 13; font.weight: Font.Bold; color: Theme.successText }
                }
            }
        }

        RowLayout {
            anchors { left: parent.left; bottom: parent.bottom; leftMargin: 80; bottomMargin: 72 }
            width: Math.min(460, parent.width - 120)
            spacing: 12
            Btn { kind: "link"; text: "Skip — Read Offline"; fontSize: 14; onClicked: Nav.home() }
            Item { Layout.fillWidth: true }
            Btn { kind: "ghost"; size: "large"; text: "Back"; fontSize: 14; onClicked: Nav.back() }
            Btn { size: "large"; text: "Continue"; fontSize: 14; leftPadding: 28; rightPadding: 28; onClicked: Nav.go("Login") }
        }
    }
}
