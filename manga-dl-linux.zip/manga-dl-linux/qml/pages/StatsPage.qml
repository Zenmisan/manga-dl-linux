import QtQuick
import QtQuick.Layouts
import MangaDl

// Reading statistics: tiles, a 52-week heatmap, goals and breakdowns.
Item {
    id: page
    function heat(level) {
        return level === 3 ? Theme.accent : level === 2 ? Theme.alpha(Theme.accent, 0xA6)
             : level === 1 ? Theme.alpha(Theme.accent, 0x59) : Theme.surface4
    }

    component BarRow: RowLayout {
        property var bar
        Layout.fillWidth: true
        spacing: 12
        Txt { text: bar.name; font.pixelSize: 13; font.weight: Font.DemiBold; Layout.preferredWidth: 100 }
        Progress { Layout.fillWidth: true; height: 8; value: bar.fraction; fill: Theme.fg; color: Theme.surfaceHigh }
    }

    PageScroll {
        anchors.fill: parent
        spacing: 22

        Column {
            PageTitle { text: "Statistics" }
            Caption { text: "Your reading habits, at a glance"; font.pixelSize: 14; topPadding: 4 }
        }

        // Stat tiles
        RowLayout {
            width: parent.width
            spacing: 14
            Repeater {
                model: [["Chapters read", "[n]"], ["Time reading", "[h]"], ["Current streak", "[d]"], ["Reading pace", "[n]/wk"]]
                Card {
                    required property var modelData
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    kind: "list"; radius: 16; padding: 18; spacing: 8
                    Txt { text: modelData[0]; font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.fgSubtle }
                    DisplayText { text: modelData[1]; font.pixelSize: 40; upper: false }
                }
            }
        }

        // 52-week heatmap (7 rows, one column per week)
        Card {
            width: parent.width
            kind: "faint"
            spacing: 12
            RowLayout {
                Layout.fillWidth: true
                Eyebrow { text: "Activity · last 52 weeks"; Layout.fillWidth: true }
                Caption { text: "Chapters per day" }
            }
            Flickable {
                Layout.fillWidth: true
                Layout.preferredHeight: heatGrid.height
                contentWidth: heatGrid.width
                clip: true
                flickableDirection: Flickable.HorizontalFlick
                boundsBehavior: Flickable.StopAtBounds
                Grid {
                    id: heatGrid
                    rows: 7
                    flow: Grid.TopToBottom
                    spacing: 4
                    Repeater {
                        model: Sample.activity
                        Rectangle { required property int modelData; width: 16; height: 16; radius: 3; color: page.heat(modelData) }
                    }
                }
            }
            Row {
                Layout.alignment: Qt.AlignRight
                spacing: 6
                Caption { text: "Less"; font.pixelSize: 11 }
                Repeater {
                    model: [0, 1, 2, 3]
                    Rectangle { required property int modelData; width: 10; height: 10; radius: 2; color: page.heat(modelData); anchors.verticalCenter: parent.verticalCenter }
                }
                Caption { text: "More"; font.pixelSize: 11 }
            }
        }

        // Goals and breakdowns
        RowLayout {
            width: parent.width
            spacing: 14
            Card {
                Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.fillHeight: true
                kind: "faint"; spacing: 14
                Eyebrow { text: "Reading goals"; muted: true }
                Repeater {
                    model: [["Monthly chapters", 0.62], ["Yearly manga", 0.35]]
                    ColumnLayout {
                        required property var modelData
                        Layout.fillWidth: true
                        spacing: 6
                        RowLayout {
                            Txt { text: modelData[0]; font.pixelSize: 13; font.weight: Font.DemiBold; Layout.fillWidth: true }
                            Txt { text: "[x] / [goal]"; font.pixelSize: 13; color: Theme.fgSubtle }
                        }
                        Progress { Layout.fillWidth: true; height: 6; value: modelData[1] }
                    }
                }
                Btn { kind: "ghost"; size: "small"; text: "Edit Goals" }
            }
            Card {
                Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.fillHeight: true
                kind: "faint"; spacing: 12
                Eyebrow { text: "By category"; muted: true }
                Repeater { model: Sample.byCategory; BarRow { required property var modelData; bar: modelData } }
            }
            Card {
                Layout.fillWidth: true; Layout.preferredWidth: 1; Layout.fillHeight: true
                kind: "faint"; spacing: 12
                Eyebrow { text: "By source"; muted: true }
                Repeater { model: Sample.bySource; BarRow { required property var modelData; bar: modelData } }
            }
        }
    }
}
