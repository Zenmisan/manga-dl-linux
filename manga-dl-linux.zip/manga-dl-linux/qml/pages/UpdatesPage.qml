import QtQuick
import QtQuick.Layouts
import MangaDl

// New chapters grouped by day.
Item {
    PageScroll {
        anchors.fill: parent
        spacing: 16

        RowLayout {
            width: parent.width
            spacing: 12
            Column {
                Layout.fillWidth: true
                PageTitle { text: "Updates" }
                Caption { text: "Last checked [time] · background sync every 30 min"; font.pixelSize: 13; topPadding: 4 }
            }
            Btn { kind: "ghost"; text: "Download All New"; iconName: "Download" }
            // TODO(backend): check sources now.
            Btn { text: "Check Now"; iconName: "Refresh"; onClicked: Nav.toast("Checking for new chapters") }
        }

        Repeater {
            model: Sample.updates
            delegate: Column {
                required property var modelData
                width: parent.width
                Eyebrow { text: modelData.title; muted: true; topPadding: 12; bottomPadding: 6 }
                Repeater {
                    model: modelData.items
                    delegate: Item {
                        required property var modelData
                        width: parent.width
                        height: 76
                        HairLine { width: parent.width }
                        RowLayout {
                            anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                            spacing: 16
                            CoverArt { width: 40; height: 60; radius: 6; cover: modelData.manga.cover }
                            Btn {
                                kind: "link"; textColor: Theme.fg; fontSize: 15; leftPadding: 0; alignLeft: true
                                text: modelData.manga.title
                                Layout.preferredWidth: 260
                                onClicked: Nav.open("MangaDetail", { manga: modelData.manga })
                            }
                            Txt { text: modelData.chapter; color: Theme.fgSoft; Layout.fillWidth: true; elide: Text.ElideRight }
                            Txt { text: modelData.source; font.pixelSize: 13; color: Theme.fgSubtle; Layout.preferredWidth: 120 }
                            Btn { kind: "ghost"; size: "small"; text: "Download"; font.weight: Font.Bold }
                            Btn { kind: "soft"; size: "small"; text: "Read"; onClicked: Nav.open("Reader", { manga: modelData.manga }) }
                        }
                    }
                }
            }
        }
    }
}
