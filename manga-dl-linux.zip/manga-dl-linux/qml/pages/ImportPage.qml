import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import MangaDl

// Import local files: drop zone, this session's queue, and options.
Item {
    id: page
    function importText(k) { return k === "done" ? Theme.successText : k === "error" ? Theme.errorText : Theme.fgMuted }
    function importBar(k) { return k === "done" ? Theme.success : k === "error" ? Theme.errorBar : k === "queued" ? "transparent" : Theme.accent }

    PageScroll {
        anchors.fill: parent

        RowLayout {
            width: parent.width
            spacing: 32

            ColumnLayout {
                Layout.fillWidth: true
                Layout.alignment: Qt.AlignTop
                spacing: 20
                PageTitle { text: "Import files" }

                // Drop zone
                Rectangle {
                    Layout.fillWidth: true
                    height: 300
                    radius: 20
                    color: drop.containsDrag ? Theme.accentMuted : Theme.accentWash
                    border.color: Theme.accent
                    border.width: 2

                    DropArea {
                        id: drop
                        anchors.fill: parent
                        // TODO(backend): import drop.urls.
                        onDropped: d => Nav.toast((d.urls.length || 0) + " item(s) queued for import")
                    }
                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 14
                        Rectangle {
                            Layout.alignment: Qt.AlignHCenter
                            width: 64; height: 64; radius: 18; color: Theme.accentMuted
                            Icon { anchors.centerIn: parent; name: "Upload"; size: 30; color: Theme.accentLight }
                        }
                        Txt { Layout.fillWidth: true; Layout.alignment: Qt.AlignHCenter; text: "Drop files to import"; font.pixelSize: 22; font.weight: Font.Black }
                        Txt { Layout.fillWidth: true; Layout.alignment: Qt.AlignHCenter; text: "CBZ, ZIP, EPUB or folders of images"; color: Theme.fgSoft }
                        Row {
                            Layout.alignment: Qt.AlignHCenter
                            Layout.topMargin: 6
                            spacing: 10
                            // TODO(backend): open a file dialog (QtQuick.Dialogs FileDialog / FolderDialog).
                            Btn { text: "Choose Files"; implicitHeight: 44; onClicked: Nav.toast("File picker opens here") }
                            Btn { kind: "ghost"; text: "Choose Folder"; implicitHeight: 44; onClicked: Nav.toast("Folder picker opens here") }
                        }
                    }
                }

                Eyebrow { text: "This session"; muted: true; Layout.topMargin: 6 }
                Repeater {
                    model: Sample.importQueue
                    delegate: Rectangle {
                        required property var modelData
                        Layout.fillWidth: true
                        height: 64
                        radius: 12
                        color: Theme.surface4
                        border.color: Theme.dividerStrong
                        RowLayout {
                            anchors { fill: parent; leftMargin: 16; rightMargin: 16 }
                            spacing: 14
                            Rectangle {
                                width: 44; height: 36; radius: 8; color: Theme.surfaceRaised
                                Txt { anchors.centerIn: parent; text: modelData.ext; font.pixelSize: 10; font.weight: Font.Black }
                            }
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 6
                                RowLayout {
                                    Txt { text: modelData.name; font.weight: Font.Bold; Layout.fillWidth: true }
                                    Txt { text: modelData.status; font.pixelSize: 12; font.weight: Font.Bold; color: page.importText(modelData.kind) }
                                }
                                Progress { Layout.fillWidth: true; value: modelData.progress; fill: page.importBar(modelData.kind); color: Theme.dividerStrong }
                            }
                        }
                    }
                }
            }

            ColumnLayout {
                Layout.fillWidth: false
                Layout.preferredWidth: 320
                Layout.alignment: Qt.AlignTop
                Layout.topMargin: 72
                spacing: 14
                Card {
                    Layout.fillWidth: true
                    kind: "list"; color: Theme.surface4; radius: 16; padding: 20; spacing: 4
                    Eyebrow { text: "Import into"; Layout.bottomMargin: 8 }
                    ButtonGroup { id: dest }
                    MdRadio { text: "New series per folder"; checked: true; ButtonGroup.group: dest }
                    MdRadio { text: "Add to existing series"; ButtonGroup.group: dest }
                    CheckRow { text: "Read ComicInfo.xml"; checked: true }
                }
                Card {
                    Layout.fillWidth: true
                    kind: "list"; color: Theme.surface4; radius: 16; padding: 20; spacing: 8
                    Eyebrow { text: "Tips"; muted: true }
                    Txt {
                        Layout.fillWidth: true
                        text: "Name folders after the series. Files are sorted by volume and chapter numbers in their names."
                        font.pixelSize: 13; color: Theme.fgSoft; wrapMode: Text.Wrap
                        lineHeightMode: Text.FixedHeight; lineHeight: 20
                    }
                    Btn { kind: "link"; text: "Read the import guide"; fontSize: 13; leftPadding: 0 }
                }
            }
        }
    }
}
