import QtQuick
import QtQuick.Layouts
import MangaDl

// Stand-in for a manga page (paper with panel outlines) until real images load.
// Replace with an Image bound to the page when wiring the reader.
Rectangle {
    property string label: ""
    color: Theme.paper

    GridLayout {
        anchors.fill: parent
        anchors.margins: 18
        columns: 2
        rowSpacing: 10
        columnSpacing: 10
        Rectangle {
            Layout.columnSpan: 2; Layout.fillWidth: true; Layout.fillHeight: true
            color: "#D4D0C6"; border.color: Theme.paperInk; border.width: 2
            Txt { anchors.centerIn: parent; text: label; color: Theme.paperText; font.pixelSize: 13; font.weight: Font.Bold }
        }
        Rectangle { Layout.fillWidth: true; Layout.fillHeight: true; color: "#DCD8CF"; border.color: Theme.paperInk; border.width: 2 }
        Rectangle { Layout.fillWidth: true; Layout.fillHeight: true; color: "#CFCAC0"; border.color: Theme.paperInk; border.width: 2 }
        Rectangle { Layout.columnSpan: 2; Layout.fillWidth: true; Layout.fillHeight: true; color: "#D8D4CA"; border.color: Theme.paperInk; border.width: 2 }
    }
}
