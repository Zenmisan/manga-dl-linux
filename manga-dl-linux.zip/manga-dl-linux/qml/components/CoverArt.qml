import QtQuick
import MangaDl

// Cover image stand-in: the manga's colour with a soft shade. Swap the Rectangle for an
// Image bound to the real cover when wiring the backend.
Rectangle {
    property string cover: "#22222A"
    property int unread: 0
    property bool downloaded: false
    radius: 12
    color: cover
    clip: true

    Rectangle {
        anchors.fill: parent
        radius: parent.radius
        gradient: Gradient {
            GradientStop { position: 0.55; color: "transparent" }
            GradientStop { position: 1.0; color: "#40000000" }
        }
    }
    Badge {
        visible: parent.unread > 0
        text: parent.unread
        height: 22; radius: 11
        anchors { left: parent.left; top: parent.top; margins: 8 }
    }
    Rectangle {
        visible: parent.downloaded
        width: 24; height: 24; radius: 12
        color: "#99000000"
        anchors { right: parent.right; top: parent.top; margins: 8 }
        Icon { anchors.centerIn: parent; name: "Download"; size: 13 }
    }
}
