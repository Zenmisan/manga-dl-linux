import QtQuick
import QtQuick.Layouts
import MangaDl

// 232px left navigation. `current` is the Nav.sidebarKey of the visible page.
Rectangle {
    id: bar
    property string current: ""
    width: 232
    color: Theme.navBg

    Rectangle { anchors { top: parent.top; bottom: parent.bottom; right: parent.right } width: 1; color: Theme.dividerStrong }

    ColumnLayout {
        anchors { fill: parent; leftMargin: 12; rightMargin: 12; topMargin: 20; bottomMargin: 16 }
        spacing: 2

        DisplayText { text: "manga-dl"; font.pixelSize: 24; Layout.leftMargin: 12; Layout.bottomMargin: 18 }

        NavItem { Layout.fillWidth: true; text: "Library"; iconName: "Library"; selected: bar.current === "Library"; onClicked: Nav.go("Library") }
        NavItem { Layout.fillWidth: true; text: "Updates"; iconName: "Updates"; badge: "8"; selected: bar.current === "Updates"; onClicked: Nav.go("Updates") }
        NavItem { Layout.fillWidth: true; text: "History"; iconName: "History"; selected: bar.current === "History"; onClicked: Nav.go("History") }
        NavItem { Layout.fillWidth: true; text: "Browse"; iconName: "Browse"; selected: bar.current === "Browse"; onClicked: Nav.go("Extensions") }
        NavItem { Layout.fillWidth: true; text: "Downloads"; iconName: "Download"; badge: "3"; selected: bar.current === "Downloads"; onClicked: Nav.go("Downloads") }
        NavItem { Layout.fillWidth: true; text: "Stats"; iconName: "Stats"; selected: bar.current === "Stats"; onClicked: Nav.go("Stats") }

        Item { Layout.fillHeight: true }

        NavItem {
            Layout.fillWidth: true
            visible: AppInfo.debugPages
            text: "All pages (debug)"; iconName: "List"
            selected: bar.current === "AllPages"
            onClicked: Nav.go("AllPages")
        }
        NavItem { Layout.fillWidth: true; text: "Notifications"; iconName: "Mail"; selected: bar.current === "Notifications"; onClicked: Nav.go("Notifications") }
        NavItem { Layout.fillWidth: true; text: "Settings"; iconName: "Settings"; selected: bar.current === "Settings"; onClicked: Nav.go("Settings") }
        NavItem { Layout.fillWidth: true; text: "Help"; iconName: "Help"; selected: bar.current === "Help"; onClicked: Nav.go("Help") }

        HairLine { Layout.fillWidth: true; Layout.topMargin: 8; color: Theme.dividerStrong }

        Clickable {
            Layout.fillWidth: true
            implicitHeight: 56
            radius: 10
            Accessible.name: "Open your profile"
            onClicked: Nav.go("Profile")
            Row {
                x: 12; y: 12
                spacing: 10
                Initial { size: 32; round: true; text: "U"; color: "#2D1716"; fontSize: 13 }
                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    Txt { text: "[Username]"; font.pixelSize: 13; font.weight: Font.Bold }
                    Caption { text: "Synced · just now"; font.pixelSize: 11 }
                }
            }
        }
    }
}
