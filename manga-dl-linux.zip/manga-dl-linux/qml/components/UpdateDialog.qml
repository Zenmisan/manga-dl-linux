import QtQuick
import QtQuick.Layouts
import MangaDl

// "Update ready" modal over the current page.
Item {
    id: dialog
    visible: opacity > 0
    opacity: 0
    Behavior on opacity { NumberAnimation { duration: Theme.fade } }
    function open() { opacity = 1; installButton.forceActiveFocus() }
    function close() { opacity = 0 }

    Keys.onEscapePressed: close()

    Rectangle {
        anchors.fill: parent
        color: Theme.scrim
        MouseArea { anchors.fill: parent; onClicked: dialog.close() }
    }

    Rectangle {
        anchors.centerIn: parent
        width: 540
        height: content.implicitHeight + 64
        radius: 20
        color: Theme.sheet
        border.color: Theme.track
        border.width: 1
        MouseArea { anchors.fill: parent }   // swallow clicks so the scrim doesn't close it

        ColumnLayout {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 32 }
            spacing: 18
            Eyebrow { text: "Update ready" }
            DisplayText { text: "manga-dl [version]"; font.pixelSize: 40 }
            BodyMuted { Layout.fillWidth: true; text: "You're on [current version]. The update is downloaded and verified." }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 6
                RowLayout {
                    Caption { text: "Downloaded"; Layout.fillWidth: true }
                    Caption { text: "100%" }
                }
                Progress { Layout.fillWidth: true; height: 6; value: 1; fill: Theme.success }
            }
            Card {
                Layout.fillWidth: true
                kind: "list"
                padding: 16
                spacing: 8
                Eyebrow { text: "What's new"; muted: true }
                Repeater {
                    model: 3
                    Txt { text: "[Release note line from the changelog]"; font.pixelSize: 13; color: Theme.fgStrong }
                }
            }
            CheckRow { text: "Install updates automatically"; checked: true; font.pixelSize: 13 }
            RowLayout {
                Layout.alignment: Qt.AlignRight
                spacing: 10
                Btn { kind: "ghost"; text: "Later"; implicitHeight: 46; fontSize: 14; onClicked: dialog.close() }
                // TODO(backend): restart into the installer.
                Btn { id: installButton; text: "Restart & Install"; implicitHeight: 46; fontSize: 14; onClicked: dialog.close() }
            }
        }
    }
}
